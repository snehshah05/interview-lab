import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import {createRequire} from 'node:module';
import ts from 'typescript';
import {webcrypto} from 'node:crypto';
const require=createRequire(import.meta.url),cache=new Map(),storage=new Map();
const localStorage={getItem:key=>storage.get(key)??null,setItem:(key,value)=>storage.set(key,value)};
function load(file){file=path.resolve(file);if(cache.has(file))return cache.get(file);const module={exports:{}};
 const context={module,exports:module.exports,require:name=>name.startsWith('.')?load(path.resolve(path.dirname(file),name+'.ts')):require(name),localStorage,Response,URL,crypto:webcrypto,console};
 vm.runInNewContext(ts.transpileModule(fs.readFileSync(file,'utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText,context,{filename:file});cache.set(file,module.exports);return module.exports;}
const {localRequest}=load('src/lib/local-api.ts');
const request=(path,body)=>localRequest(path,{method:'POST',body:JSON.stringify(body)});
const seen=new Set();let question;
for(let i=0;i<3;i++){const r=await request('/api/questions',{role:'Frontend Developer',count:25});assert.equal(r.status,200);const d=await r.json();assert.equal(d.questions.length,25);assert.equal(d.reused,0);for(const q of d.questions){assert.ok(!seen.has(q.title));seen.add(q.title);}question=d.questions[0];}
assert.equal(seen.size,75);const repeat=await(await request('/api/questions',{role:'Frontend Developer',count:5})).json();assert.equal(repeat.reused,5);
const aiRepeat=await request('/api/questions',{role:'Frontend Developer',count:5,questions:repeat.questions});assert.equal(aiRepeat.status,409);
const evaluation=await(await request('/api/evaluate',{question,answer:'First I would explain my approach because a concrete example helps.'})).json();assert.equal(evaluation.technical,null);assert.equal(evaluation.confidence,null);
const session={id:webcrypto.randomUUID(),role:'Frontend Developer',level:'Intermediate',created:new Date().toISOString(),answers:[{question,text:'First I would explain my approach.',evaluation}]};assert.equal((await request('/api/interviews',session)).status,200);assert.equal((await(await localRequest('/api/interviews')).json())[0].id,session.id);
assert.equal((await request('/api/questions',{role:'invalid',count:5})).status,503);
console.log('PASS: unseen selection, exhausted pool, duplicate rejection, local feedback and saved history.');
