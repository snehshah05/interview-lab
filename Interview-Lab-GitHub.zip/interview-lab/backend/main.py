"""Authenticated, database-backed interview API. Run: uvicorn backend.main:app."""
import asyncio
import hashlib
import os
import re
import secrets
from collections import Counter
from contextlib import asynccontextmanager
from difflib import SequenceMatcher
from uuid import uuid4
from dotenv import load_dotenv
from fastapi import FastAPI, Depends, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from sqlalchemy import select, update, text
from sqlalchemy.exc import IntegrityError
from .database import initialize, connect, Interview, AnswerRow, Exposure
from .models import Batch, Evaluation, CreateSession, SubmitAnswer
from .llm import generate, QUESTION_PROMPT, EVALUATION_PROMPT

load_dotenv(os.path.join(os.path.dirname(__file__), '.env'))

@asynccontextmanager
async def lifespan(app):
    initialize()
    yield

app = FastAPI(title='Interview Lab AI', version='2.0.0', lifespan=lifespan)
app.add_middleware(CORSMiddleware,
    allow_origins=[s.strip() for s in os.getenv('ALLOWED_ORIGINS', 'http://localhost:5173,https://snehshah05.github.io').split(',')],
    allow_methods=['GET', 'POST'], allow_headers=['Content-Type', 'Authorization'])
security = HTTPBearer(auto_error=False)

async def owner(credentials: HTTPAuthorizationCredentials | None = Depends(security)):
    # Provision a separate high-entropy token per workspace. No provider key reaches the browser.
    tokens = [t.strip() for t in os.getenv('WORKSPACE_TOKENS', '').split(',') if len(t.strip()) >= 32]
    if not tokens:
        raise HTTPException(503, 'Server needs WORKSPACE_TOKENS (at least 32 characters each).')
    token = credentials.credentials if credentials else ''
    if not any(secrets.compare_digest(token.encode(), allowed.encode()) for allowed in tokens):
        raise HTTPException(401, 'Invalid workspace access token.', headers={'WWW-Authenticate': 'Bearer'})
    return hashlib.sha256(token.encode()).hexdigest()

# One model operation per API process; immediately reject excess load rather than queue indefinitely.
model_gate = asyncio.Semaphore(1)
@asynccontextmanager
async def model_slot():
    if model_gate.locked():
        raise HTTPException(429, 'The model is busy. Retry shortly; your transcript is preserved.', headers={'Retry-After': '10'})
    async with model_gate:
        yield

def normalize(title):
    return ' '.join(re.findall(r'\w+', title.casefold()))

def fingerprint(title):
    return hashlib.sha256(normalize(title).encode()).hexdigest()

def repeats(title, prior):
    current = normalize(title)
    return any(current == normalize(old) or SequenceMatcher(None, current, normalize(old)).ratio() >= .88 for old in prior)

def owned(db, session_id, user):
    session = db.get(Interview, session_id)
    if session is None or session.owner != user:
        raise HTTPException(404, 'Interview not found.')
    return session

def answer_rows(db, session_id):
    return list(db.scalars(select(AnswerRow).where(AnswerRow.session_id == session_id).order_by(AnswerRow.created, AnswerRow.id)))

def report(db, session):
    return {'id': session.id, 'role': session.role, 'level': session.level, 'created': session.created,
        'status': session.status, 'count': session.count,
        'answers': [{'question': a.question, 'text': a.transcript, 'evaluation': a.evaluation} for a in answer_rows(db, session.id)]}

def historical_context(db, user, role, level):
    sessions = list(db.scalars(select(Interview).where(Interview.owner == user, Interview.role == role, Interview.level == level).order_by(Interview.created.desc()).limit(10)))
    missing = Counter()
    for session in sessions:
        for answer in answer_rows(db, session.id):
            missing.update(answer.evaluation.get('missing', []))
    return {'weak_topics': [topic for topic, _ in missing.most_common(12)], 'recent_session_count': len(sessions)}

@app.get('/health')
def health(user=Depends(owner)):
    with connect() as db:
        db.execute(text('SELECT 1'))
    return {'status': 'ok', 'api_version': 2, 'llm': bool(os.getenv('LLM_MODEL')), 'database': True}

@app.post('/sessions')
async def create_session(data: CreateSession, user=Depends(owner)):
    async with model_slot():
        with connect() as db:
            prior = list(db.scalars(select(Exposure.title).where(Exposure.owner == user, Exposure.role == data.role).order_by(Exposure.created.desc())))
            context = historical_context(db, user, data.role, data.level)
        accepted = None
        for _ in range(3):
            batch = await generate(Batch, QUESTION_PROMPT, {**data.model_dump(), 'previous_questions': prior[:300], 'progress': context, 'variation_seed': str(uuid4())}, .8)
            titles = [q.title for q in batch.questions]
            if len(titles) == data.count and all(not repeats(title, prior + titles[:i]) for i, title in enumerate(titles)):
                accepted = batch.questions
                break
            # Retry whole batch with rejected suggestions added to the prompt, never silently use bank questions.
            context['rejected_questions'] = titles
        if accepted is None:
            raise HTTPException(502, 'The model repeated questions or returned the wrong count. Retry with a different model or session length.')
        deck = [{**q.model_dump(), 'id': str(uuid4())} for q in accepted]
        session = Interview(id=str(uuid4()), owner=user, role=data.role, level=data.level, count=data.count, deck=deck)
        try:
            with connect() as db:
                db.add(session)
                for question in deck:
                    db.add(Exposure(id=str(uuid4()), owner=user, role=data.role, title=question['title'], fingerprint=fingerprint(question['title'])))
                db.commit()
        except IntegrityError as exc:
            raise HTTPException(409, 'Questions overlapped with a concurrent session. Retry generation.') from exc
        return {'id': session.id, 'questions': deck, 'mode': 'AI-generated', 'reused': 0}

@app.post('/sessions/{session_id}/answers')
async def submit_answer(session_id: str, data: SubmitAnswer, user=Depends(owner)):
    async with model_slot():
        with connect() as db:
            session = owned(db, session_id, user)
            rows = answer_rows(db, session_id)
            previous = next((a for a in rows if a.question_id == data.question_id), None)
            if previous:
                if previous.transcript != data.answer:
                    raise HTTPException(409, 'This question already has a saved answer.')
                return previous.evaluation
            if session.status != 'in_progress' or len(rows) >= session.count:
                raise HTTPException(409, 'This interview is complete.')
            eligible = session.deck + [a.evaluation['followup_question'] for a in rows if a.evaluation.get('followup_question')]
            question = next((q for q in eligible if q['id'] == data.question_id), None)
            if question is None:
                raise HTTPException(400, 'Question does not belong to this interview.')
            revision = session.revision
            payload = {'role': session.role, 'level': session.level, 'question': question, 'answer': data.answer,
                'conversation': [{'question': a.question['title'], 'answer': a.transcript[:3000]} for a in rows[-3:]]}
            role = session.role
            prior_titles = list(db.scalars(select(Exposure.title).where(Exposure.owner == user, Exposure.role == role)))
        result = await generate(Evaluation, EVALUATION_PROMPT, payload, .2)
        # Quote grounding is checked outside the model, so hallucinated evidence is never displayed.
        if any(m.quote not in data.answer for m in result.mistakes):
            raise HTTPException(502, 'Model feedback contained an unsupported quote. Retry evaluation; your transcript is preserved.')
        output = result.model_dump()
        followup = output['followup_question']
        followup['id'] = str(uuid4())
        followup['parent_id'] = question['id']
        followup['topic'] = 'Follow-up · ' + followup['topic'].removeprefix('Follow-up · ')[:180]
        # A follow-up is optional if redundant or this was already a follow-up / final answer.
        can_follow = not question.get('parent_id') and len(rows) + 1 < session.count and not repeats(followup['title'], prior_titles)
        output.update(confidence=None, mode='LLM semantic evaluation', model=os.getenv('LLM_MODEL'),
            followup=followup['title'] if can_follow else '', followup_question=followup if can_follow else None)
        try:
            with connect() as db:
                changed = db.execute(update(Interview).where(Interview.id == session_id, Interview.owner == user,
                    Interview.revision == revision, Interview.status == 'in_progress').values(revision=revision + 1))
                if changed.rowcount != 1:
                    raise HTTPException(409, 'Interview changed in another tab. Refresh history or retry.')
                db.add(AnswerRow(id=str(uuid4()), session_id=session_id, question_id=question['id'], question=question, transcript=data.answer, evaluation=output))
                if can_follow:
                    db.add(Exposure(id=str(uuid4()), owner=user, role=role, title=followup['title'], fingerprint=fingerprint(followup['title'])))
                db.commit()
        except IntegrityError as exc:
            raise HTTPException(409, 'A concurrent submission was saved first. Retry to retrieve it.') from exc
        return output

@app.post('/sessions/{session_id}/complete')
def complete(session_id: str, user=Depends(owner)):
    with connect() as db:
        session = owned(db, session_id, user)
        if not answer_rows(db, session_id):
            raise HTTPException(400, 'Answer at least one question before completing the report.')
        db.execute(update(Interview).where(Interview.id == session_id).values(status='completed', revision=Interview.revision + 1))
        db.commit()
        db.refresh(session)
        return report(db, session)

@app.get('/sessions')
def history(user=Depends(owner)):
    with connect() as db:
        sessions = list(db.scalars(select(Interview).where(Interview.owner == user).order_by(Interview.created.desc()).limit(100)))
        return [report(db, s) for s in sessions]

@app.get('/progress')
def progress(user=Depends(owner)):
    with connect() as db:
        sessions = list(db.scalars(select(Interview).where(Interview.owner == user).order_by(Interview.created)))
        groups = {}
        for session in sessions:
            rows = answer_rows(db, session.id)
            if not rows:
                continue
            key = (session.role, session.level)
            group = groups.setdefault(key, {'role': session.role, 'level': session.level, 'sessions': 0, 'answered': 0, 'trend': [], 'weaknesses': Counter()})
            group['sessions'] += 1
            group['answered'] += len(rows)
            scores = {name: round(sum(a.evaluation[name] for a in rows) / len(rows)) for name in ('technical', 'completeness', 'communication')}
            group['trend'].append({'id': session.id, 'date': session.created, 'status': session.status, **scores})
            # Count each gap once per answer across saved sessions.
            for a in rows:
                group['weaknesses'].update(set(a.evaluation.get('missing', [])))
        for group in groups.values():
            group['weaknesses'] = [{'topic': k, 'mentions': v} for k, v in group['weaknesses'].most_common(8)]
            group['trend'] = group['trend'][-20:]
        return {'groups': list(groups.values())}
