"""Deterministic API integration tests. Model outputs are fixtures, not a quality benchmark."""
import json
import pytest
from fastapi.testclient import TestClient
from backend import main, database
from backend.models import Batch, Evaluation

TOKEN_A = 'test-workspace-a-' + 'a' * 32
TOKEN_B = 'test-workspace-b-' + 'b' * 32
TITLES = ['How would you diagnose an API that becomes slow only during traffic spikes?',
          'Design reliable processing for payment events that may arrive more than once.',
          'Compare cursor pagination and offset pagination for a frequently updated feed.',
          'Explain how you would investigate a database deadlock in a checkout transaction.',
          'What strategy would you use to roll out a breaking schema change safely?']

def question(title):
    return {'title': title, 'topic': 'Backend systems', 'concepts': ['trade-offs', 'correctness'], 'reference': 'Identify constraints, compare approaches and explain failure handling.', 'followup': ''}

def feedback():
    return {'technical': 85, 'completeness': 75, 'communication': 80, 'covered': ['correctness'], 'missing': ['trade-offs'],
        'feedback': 'You explained the behavior accurately. Add a concrete failure scenario and its trade-offs.', 'mistakes': [],
        'strengths': ['Clear explanation of the mechanism.'], 'improvement': 'Explain how a retry changes the behavior.',
        'followup_question': question('You proposed retrying payments. How would you prevent duplicate charges after a timeout?')}

@pytest.fixture
def api(tmp_path, monkeypatch):
    monkeypatch.setenv('DATABASE_URL', f'sqlite:///{tmp_path}/interview.db')
    monkeypatch.setenv('WORKSPACE_TOKENS', TOKEN_A + ',' + TOKEN_B)
    monkeypatch.setenv('LLM_MODEL', 'fixture-model')
    database.engine.cache_clear()
    calls = []
    async def generate(schema, instruction, payload, temperature):
        calls.append((instruction, payload))
        return schema.model_validate({'questions': [question(t) for t in TITLES]} if schema == Batch else feedback())
    monkeypatch.setattr(main, 'generate', generate)
    with TestClient(main.app) as client:
        client.headers['Authorization'] = f'Bearer {TOKEN_A}'
        yield client, calls
    database.engine().dispose()
    database.engine.cache_clear()

def create(client, **changes):
    return client.post('/sessions', json={'role': 'Backend Developer', 'level': 'Intermediate', 'count': 5, **changes})

def test_authentication_and_validation(api):
    client, _ = api
    assert client.get('/health', headers={'Authorization': ''}).status_code == 401
    assert create(client, count=7).status_code == 422
    assert create(client, role='invented').status_code == 422
    assert client.get('/health').json()['database'] is True

def test_persistence_followups_and_workspace_isolation(api):
    client, calls = api
    session = create(client).json()
    sid = session['id']
    qid = session['questions'][0]['id']
    body = {'question_id': qid, 'answer': 'I would profile the latency under realistic load before changing the architecture.'}
    response = client.post(f'/sessions/{sid}/answers', json=body)
    assert response.status_code == 200, response.text
    result = response.json()
    follow = result['followup_question']
    assert follow['parent_id'] == qid
    assert follow['id'] != qid
    assert client.post(f'/sessions/{sid}/answers', json=body).json() == result
    assert len(calls) == 2  # retry retrieves persisted feedback instead of charging twice
    assert client.post(f'/sessions/{sid}/answers', json={**body, 'answer': 'A different transcript cannot replace an evaluated answer.'}).status_code == 409
    unknown = {**body, 'question_id': '00000000-0000-0000-0000-000000000000'}
    assert client.post(f'/sessions/{sid}/answers', json=unknown).status_code == 400
    r = client.post(f'/sessions/{sid}/answers', json={'question_id': follow['id'], 'answer': 'I would persist an idempotency key atomically with the payment result.'})
    assert r.status_code == 200
    assert r.json()['followup_question'] is None
    assert calls[-1][1]['question']['reference'] == follow['reference']
    assert 'MEANING' in calls[-1][0] and 'paraphrasing' in calls[-1][0]
    assert len(client.get('/sessions').json()[0]['answers']) == 2
    assert client.get('/progress').json()['groups'][0]['answered'] == 2
    report = client.post(f'/sessions/{sid}/complete').json()
    assert report['status'] == 'completed'
    assert client.post(f'/sessions/{sid}/answers', json={'question_id': session['questions'][1]['id'], 'answer': 'A new answer after completion should not be allowed.'}).status_code == 409
    # Reopen DB engine to demonstrate persistence independent of API memory.
    database.engine().dispose()
    database.engine.cache_clear()
    assert client.get('/sessions').json()[0]['answers'][0]['text'] == body['answer']
    other = {'Authorization': f'Bearer {TOKEN_B}'}
    assert client.get('/sessions', headers=other).json() == []
    assert client.get('/progress', headers=other).json() == {'groups': []}
    assert client.post(f'/sessions/{sid}/complete', headers=other).status_code == 404

def test_previous_sessions_feed_generation_and_repeat_rejection(api):
    client, calls = api
    first = create(client).json()
    client.post(f"/sessions/{first['id']}/answers", json={'question_id': first['questions'][0]['id'], 'answer': 'I would measure the slowest component using distributed traces.'})
    retry = create(client)
    assert retry.status_code == 502
    payload = calls[-1][1]
    assert TITLES[0] in payload['previous_questions']
    assert payload['progress']['weak_topics'] == ['trade-offs']
    assert main.repeats(TITLES[0].upper() + '!', TITLES)

def test_unsupported_quotes_are_not_saved(api, monkeypatch):
    client, _ = api
    session = create(client).json()
    async def bad(*args):
        data = feedback()
        data['mistakes'] = [{'quote': 'words never spoken', 'correction': 'A fabricated correction.'}]
        return Evaluation.model_validate(data)
    monkeypatch.setattr(main, 'generate', bad)
    response = client.post(f"/sessions/{session['id']}/answers", json={'question_id': session['questions'][0]['id'], 'answer': 'This candidate gave a valid and carefully structured answer.'})
    assert response.status_code == 502
    assert client.get('/sessions').json()[0]['answers'] == []

def test_model_failure_never_fakes_scores(api, monkeypatch):
    client, _ = api
    session = create(client).json()
    async def failed(*args):
        raise main.HTTPException(502, 'Model unavailable')
    monkeypatch.setattr(main, 'generate', failed)
    r = client.post(f"/sessions/{session['id']}/answers", json={'question_id': session['questions'][0]['id'], 'answer': 'This answer must survive a model outage in the frontend.'})
    assert r.status_code == 502
    assert client.get('/sessions').json()[0]['answers'] == []

def test_json_client_repairs_invalid_output(monkeypatch):
    import asyncio
    import httpx
    from backend import llm
    monkeypatch.setenv('LLM_MODEL', 'fixture-model')
    requests = []
    def handler(request):
        requests.append(json.loads(request.content))
        content = '{bad' if len(requests) == 1 else json.dumps(feedback())
        return httpx.Response(200, json={'choices': [{'message': {'content': content}}]})
    real_client = httpx.AsyncClient
    monkeypatch.setattr(llm.httpx, 'AsyncClient', lambda **kwargs: real_client(transport=httpx.MockTransport(handler), **kwargs))
    result = asyncio.run(llm.generate(Evaluation, main.EVALUATION_PROMPT, {'answer': 'test'}, .2))
    assert result.technical == 85 and len(requests) == 2
    assert requests[0]['response_format'] == {'type': 'json_object'}
