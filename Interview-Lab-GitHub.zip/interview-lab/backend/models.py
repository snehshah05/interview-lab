"""Validated API and LLM contracts. Questions are owned by the server."""
from typing import Annotated, Literal
from pydantic import BaseModel, Field, ConfigDict

Short = Annotated[str, Field(min_length=1, max_length=100)]
Score = Annotated[int, Field(strict=True, ge=0, le=100)]
Role = Literal['AI / ML Engineer', 'Frontend Developer', 'Backend Developer', 'Full-stack Developer', 'Mobile Application Developer', 'Cybersecurity Analyst', 'Data Analyst']
Level = Literal['Entry level', 'Intermediate', 'Senior']

class Question(BaseModel):
    model_config = ConfigDict(extra='ignore')
    title: str = Field(min_length=5, max_length=2000)
    topic: str = Field(min_length=1, max_length=200)
    concepts: list[Short] = Field(min_length=1, max_length=20)
    reference: str = Field(min_length=10, max_length=5000)
    followup: str = Field(default='', max_length=2000)

class Batch(BaseModel):
    questions: list[Question] = Field(min_length=5, max_length=25)

class Mistake(BaseModel):
    quote: str = Field(min_length=1, max_length=1500)
    correction: str = Field(min_length=1, max_length=2500)

class Evaluation(BaseModel):
    technical: Score
    completeness: Score
    communication: Score
    covered: list[Short] = Field(max_length=20)
    missing: list[Short] = Field(max_length=20)
    feedback: str = Field(min_length=10, max_length=10000)
    mistakes: list[Mistake] = Field(max_length=8)
    strengths: list[Annotated[str, Field(max_length=1000)]] = Field(max_length=5)
    improvement: str = Field(min_length=5, max_length=2500)
    followup_question: Question

class CreateSession(BaseModel):
    role: Role
    level: Level
    count: Literal[5, 10, 15, 20, 25]

class SubmitAnswer(BaseModel):
    question_id: str = Field(min_length=36, max_length=36)
    answer: str = Field(min_length=10, max_length=15000)
