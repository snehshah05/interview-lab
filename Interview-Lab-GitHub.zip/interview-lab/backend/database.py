"""SQLAlchemy storage: SQLite for local use, PostgreSQL for hosted use."""
import os
from datetime import datetime, timezone
from pathlib import Path
from functools import lru_cache
from sqlalchemy import create_engine, String, Integer, JSON, Text, UniqueConstraint
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, sessionmaker

class Base(DeclarativeBase):
    pass

def now():
    return datetime.now(timezone.utc).isoformat()

class Interview(Base):
    __tablename__ = 'ai_interviews_v2'
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    owner: Mapped[str] = mapped_column(String(64), index=True)
    role: Mapped[str] = mapped_column(String(100))
    level: Mapped[str] = mapped_column(String(100))
    count: Mapped[int] = mapped_column(Integer)
    created: Mapped[str] = mapped_column(String(40), default=now)
    status: Mapped[str] = mapped_column(String(20), default='in_progress')
    deck: Mapped[list] = mapped_column(JSON)
    # Optimistic version prevents concurrent submissions exceeding the session budget.
    revision: Mapped[int] = mapped_column(Integer, default=0, nullable=False)

class AnswerRow(Base):
    __tablename__ = 'ai_answers_v2'
    __table_args__ = (UniqueConstraint('session_id', 'question_id'),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    session_id: Mapped[str] = mapped_column(String(36), index=True)
    question_id: Mapped[str] = mapped_column(String(36))
    created: Mapped[str] = mapped_column(String(40), default=now)
    question: Mapped[dict] = mapped_column(JSON)
    transcript: Mapped[str] = mapped_column(Text)
    evaluation: Mapped[dict] = mapped_column(JSON)

class Exposure(Base):
    __tablename__ = 'ai_exposures_v2'
    __table_args__ = (UniqueConstraint('owner', 'role', 'fingerprint'),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    owner: Mapped[str] = mapped_column(String(64), index=True)
    role: Mapped[str] = mapped_column(String(100))
    title: Mapped[str] = mapped_column(Text)
    fingerprint: Mapped[str] = mapped_column(String(64))
    created: Mapped[str] = mapped_column(String(40), default=now)

@lru_cache(maxsize=1)
def engine():
    default = Path(__file__).resolve().parent / 'data' / 'interviews.sqlite3'
    default.parent.mkdir(exist_ok=True)
    url = os.getenv('DATABASE_URL') or f'sqlite:///{default}'
    if url.startswith('postgres://'):
        url = url.replace('postgres://', 'postgresql+psycopg://', 1)
    elif url.startswith('postgresql://'):
        url = url.replace('postgresql://', 'postgresql+psycopg://', 1)
    kwargs = {'connect_args': {'check_same_thread': False, 'timeout': 30}} if url.startswith('sqlite') else {}
    return create_engine(url, pool_pre_ping=True, **kwargs)

def initialize():
    # Versioned initial schema. Future schema changes require an explicit migration.
    Base.metadata.create_all(engine())

def connect():
    return sessionmaker(engine(), expire_on_commit=False)()
