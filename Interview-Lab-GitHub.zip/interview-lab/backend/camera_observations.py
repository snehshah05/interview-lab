"""Local-only landmark observations; no emotion, confidence or gaze inference.
Usage: python camera_observations.py /path/to/pose_landmarker.task
Download the MediaPipe Pose Landmarker model separately from its official model page.
"""
import sys
import cv2
import mediapipe as mp
from mediapipe.tasks import python
from mediapipe.tasks.python import vision

def main(model):
    options=vision.PoseLandmarkerOptions(base_options=python.BaseOptions(model_asset_path=model),num_poses=1)
    cap=cv2.VideoCapture(0)
    try:
        with vision.PoseLandmarker.create_from_options(options) as detector:
            while cap.isOpened():
                ok,frame=cap.read()
                if not ok: break
                rgb=cv2.cvtColor(frame,cv2.COLOR_BGR2RGB)
                result=detector.detect(mp.Image(image_format=mp.ImageFormat.SRGB,data=rgb))
                message='Move into frame'
                if result.pose_landmarks:
                    points=result.pose_landmarks[0]
                    left,right=points[11],points[12]
                    if min(left.visibility,right.visibility)<0.6: message='Keep both shoulders visible'
                    else:
                        center=(left.x+right.x)/2
                        tilt=abs(left.y-right.y)
                        message='Centered in frame' if abs(center-0.5)<0.15 else 'Try centering your shoulders'
                        if tilt>0.08: message+=' | Shoulders appear tilted'
                cv2.putText(frame,message,(16,32),cv2.FONT_HERSHEY_SIMPLEX,.6,(160,240,160),2)
                cv2.imshow('Framing practice - Q to quit',frame)
                if cv2.waitKey(1)&0xFF==ord('q'): break
    finally:
        cap.release();cv2.destroyAllWindows()
if __name__=='__main__': main(sys.argv[1])
