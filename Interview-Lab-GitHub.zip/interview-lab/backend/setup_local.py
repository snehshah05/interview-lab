"""One-time local configuration. Never commits a token or provider key."""
from pathlib import Path
import secrets
from dotenv import dotenv_values

path = Path(__file__).with_name('.env')
if path.exists():
    print('Existing backend/.env preserved. Edit it to change model configuration.')
else:
    model = input('Installed Ollama model name (from ollama list): ').strip()
    if not model or any(c in model for c in '\r\n"\''):
        raise SystemExit('Enter a valid installed model name.')
    token = secrets.token_urlsafe(32)
    path.write_text(
        f'WORKSPACE_TOKENS={token}\nLLM_MODEL={model}\n'
        'LLM_BASE_URL=http://127.0.0.1:11434/v1\nLLM_API_KEY=\n'
        'ALLOWED_ORIGINS=http://localhost:5173,https://snehshah05.github.io\nDATABASE_URL=\n', encoding='utf-8')
    try:
        path.chmod(0o600)
    except OSError:
        pass
    print('Created backend/.env. Keep this file private; it identifies your saved workspace.')
config = dotenv_values(path)
print('Service URL for Connections: http://localhost:8000')
print('Your private workspace access token:', config.get('WORKSPACE_TOKENS', '').split(',')[0])
print('Start the API: python -m uvicorn backend.main:app --host 127.0.0.1 --port 8000')
