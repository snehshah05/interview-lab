export async function aiRequest(base:string,token:string,path:string,body?:unknown){
 const url=new URL(base);
 if(!['https:','http:'].includes(url.protocol)||(url.protocol!=='https:'&&!['localhost','127.0.0.1'].includes(url.hostname)))throw Error('Use HTTPS for a hosted service, or HTTP on localhost.');
 if(url.username||url.password||url.search||url.hash)throw Error('Use a plain service URL without credentials or query parameters.');
 const response=await fetch(base.replace(/\/$/,'')+path,{method:body===undefined?'GET':'POST',headers:{'Content-Type':'application/json','Authorization':'Bearer '+token},body:body===undefined?undefined:JSON.stringify(body),signal:AbortSignal.timeout(540000)});
 const data=await response.json().catch(()=>null);
 if(!response.ok)throw Error(typeof data?.detail==='string'?data.detail:`Service request failed (${response.status}). Your transcript is preserved.`);
 return data;
}
