export type Question={title:string;topic:string;concepts:string[];reference:string;followup:string};
export const banks:Record<string,Question[]>={
'AI / ML Engineer':[
{title:'Your model performs well on training data, but poorly on unseen data. How would you investigate and improve it?',topic:'Model evaluation',concepts:['overfitting','validation','regularization','data leakage'],reference:'Compare training and validation metrics using a representative holdout or cross-validation. Check leakage and distribution shifts. For overfitting, try regularization, a simpler model, more representative data, or early stopping. Keep the final test set untouched.',followup:'How would you prevent data leakage when preprocessing data during cross-validation?'},
{title:'How would you evaluate a fraud detection model when only 1% of transactions are fraudulent?',topic:'Classification',concepts:['precision','recall','imbalance','threshold'],reference:'Accuracy is misleading with class imbalance. Evaluate precision, recall, PR-AUC and a confusion matrix. Choose a threshold from the cost of false positives and false negatives, using representative validation data.',followup:'What happens to precision and recall when you lower the decision threshold?'},
{title:'Explain how a CNN learns useful features from an image.',topic:'Deep learning',concepts:['convolution','filters','activation','pooling'],reference:'Learned convolution filters detect local patterns. Nonlinear activations allow complex functions. Deeper layers combine patterns into higher-level features; pooling can reduce spatial dimensions. Backpropagation updates weights to minimize a loss.',followup:'Why does parameter sharing make a CNN more efficient than a fully connected network for images?'},
{title:'Design a question-answering system over a company’s internal documents.',topic:'RAG & systems',concepts:['embedding','retrieval','chunk','evaluation'],reference:'Parse and chunk documents, embed and index them, retrieve relevant chunks and pass them as context to an LLM. Enforce document access permissions, cite sources and evaluate retrieval quality, answer faithfulness and latency.',followup:'How would you determine whether a bad answer comes from retrieval or generation?'},
{title:'How would you deploy and monitor a machine learning model in production?',topic:'MLOps',concepts:['api','monitor','drift','version'],reference:'Version the model and preprocessing, expose a validated API, test latency and reliability, and monitor input drift and delayed outcome metrics. Use staged rollout, logging and a rollback plan.',followup:'What would you monitor if ground-truth labels arrive only after a month?'}],
'Full-stack Developer':[
{title:'Design a secure login flow for a web application.',topic:'Authentication',concepts:['hash','session','cookie','csrf'],reference:'Hash passwords with an adaptive password hash, use HTTPS and secure HttpOnly cookies, rotate sessions and protect against CSRF and brute-force attacks. Validate authorization server-side.',followup:'Why should a session cookie be HttpOnly?'},
{title:'A React page feels slow. How would you diagnose and improve it?',topic:'React performance',concepts:['profil','render','memo','network'],reference:'Measure with a profiler and browser tools, find expensive renders or network bottlenecks, then apply targeted memoization, pagination or virtualization, code splitting and caching. Measure again.',followup:'When can memoization make performance worse?'},
{title:'How would you design a REST API for an expense tracker?',topic:'API design',concepts:['validation','authentication','pagination','status'],reference:'Use resource-based routes, request validation, per-user authorization, appropriate status codes, pagination and consistent errors. Make retryable operations safe.',followup:'How would you prevent one user from reading another user’s expenses?'},
{title:'When would you add a database index, and what are the trade-offs?',topic:'Databases',concepts:['query','index','write','explain'],reference:'Inspect slow queries and execution plans. Index selective filter, join and sort columns; consider composite column order. Indexes consume storage and slow writes.',followup:'How does column order affect a composite index?'},
{title:'How would you test and release a change without breaking production?',topic:'Delivery',concepts:['test','staging','rollback','monitor'],reference:'Use meaningful automated tests, staging checks, migrations compatible with running code, a staged release and monitoring with a clear rollback procedure.',followup:'How would you safely deploy a database schema change?'}],
'Data Analyst':[
{title:'How would you investigate a sudden drop in weekly revenue?',topic:'Business analysis',concepts:['segment','quality','trend','hypothesis'],reference:'Validate data quality and metric definitions, compare historical trends and seasonality, segment by product or channel, and test hypotheses against volume, price and conversion changes.',followup:'How would you separate a tracking issue from a real business decline?'},
{title:'Explain the difference between INNER JOIN and LEFT JOIN with a practical example.',topic:'SQL',concepts:['match','left','null','duplicate'],reference:'INNER JOIN returns matching pairs. LEFT JOIN preserves all left rows, filling unmatched right columns with NULL. One-to-many matches may duplicate left records and inflate aggregates.',followup:'How can a WHERE clause accidentally turn a LEFT JOIN into an INNER JOIN?'},
{title:'How would you design and analyze an A/B test?',topic:'Experimentation',concepts:['random','sample','significance','metric'],reference:'Choose a primary metric and guardrails, randomly assign users, plan sample size and duration, and assess effect size and uncertainty without repeated uncorrected peeking.',followup:'What does a statistically significant result fail to tell you?'},
{title:'What would you do with missing values in a dataset?',topic:'Data quality',concepts:['missing','bias','imput','distribution'],reference:'Investigate the mechanism and pattern of missingness, quantify impact, then choose exclusion, imputation or a missingness indicator. Check bias and distributions and document assumptions.',followup:'When could filling missing values with the mean introduce bias?'},
{title:'How would you communicate an analysis to a nontechnical stakeholder?',topic:'Communication',concepts:['decision','visual','uncertainty','action'],reference:'Start with the decision, show a clear relevant visual, explain impact and uncertainty in plain language, and propose an action with limitations.',followup:'How would you explain correlation without implying causation?'}]
};

// Role-specific question banks: each track contains 15 distinct main questions.
banks["Frontend Developer"]=[
  {
    "title": "How would you build a navigation menu usable with a keyboard and screen reader?",
    "topic": "HTML & accessibility",
    "concepts": [
      "semantic",
      "keyboard",
      "focus",
      "aria"
    ],
    "reference": "Use semantic navigation and links, a real button for toggling, visible focus, correct expanded state, and predictable keyboard behavior. Test with a screen reader; do not replace native semantics unnecessarily.",
    "followup": "How would you manage focus when a mobile menu opens and closes?"
  },
  {
    "title": "When would you choose Flexbox instead of CSS Grid?",
    "topic": "CSS layout",
    "concepts": [
      "flexbox",
      "grid",
      "dimension",
      "alignment"
    ],
    "reference": "Flexbox primarily distributes items in one dimension; Grid coordinates rows and columns. Choose based on layout relationships, consider wrapping and intrinsic sizing, and avoid unnecessary fixed dimensions.",
    "followup": "How would you make a card grid adapt without many media queries?"
  },
  {
    "title": "How would you debug a page that scrolls horizontally on mobile?",
    "topic": "Responsive design",
    "concepts": [
      "overflow",
      "viewport",
      "width",
      "responsive"
    ],
    "reference": "Inspect the overflowing element, viewport settings, fixed widths, long content and flex minimum sizes. Fix the cause with responsive sizing and wrapping; hiding overflow alone may conceal inaccessible content.",
    "followup": "Why can a flex child overflow even when its parent fits the viewport?"
  },
  {
    "title": "Explain closures with an example where they are useful.",
    "topic": "JavaScript scope",
    "concepts": [
      "closure",
      "scope",
      "function",
      "variable"
    ],
    "reference": "A closure gives a function access to its lexical environment after the outer function returns. Use a counter or callback example, and discuss retained references and stale captured values.",
    "followup": "How can a closure lead to a stale value in a React effect?"
  },
  {
    "title": "Explain the event loop and how promises differ from timers.",
    "topic": "Asynchronous JavaScript",
    "concepts": [
      "call stack",
      "microtask",
      "queue",
      "promise"
    ],
    "reference": "Synchronous code runs on the call stack. Promise reactions enter the microtask queue, typically drained before the next task such as a timer callback. Long synchronous tasks block rendering and input.",
    "followup": "What prints first when synchronous logs, a resolved promise and a zero-delay timer are mixed?"
  },
  {
    "title": "When should data be React state, a prop, or a derived value?",
    "topic": "React state",
    "concepts": [
      "state",
      "prop",
      "derived",
      "source"
    ],
    "reference": "Keep mutable UI data in an appropriate state owner, pass it through props, and derive values that can be computed from existing inputs. Avoid duplicate sources of truth and mutate state immutably.",
    "followup": "Why can copying props into state cause synchronization bugs?"
  },
  {
    "title": "How would you fetch data safely inside a React effect?",
    "topic": "React effects",
    "concepts": [
      "dependency",
      "cleanup",
      "abort",
      "race"
    ],
    "reference": "Declare dependencies accurately, handle loading and errors, and abort or ignore obsolete requests during cleanup. Prevent an older request from overwriting newer results.",
    "followup": "What happens if the user changes a search query before the previous request finishes?"
  },
  {
    "title": "Design an accessible signup form with client and server validation.",
    "topic": "Forms",
    "concepts": [
      "label",
      "validation",
      "error",
      "server"
    ],
    "reference": "Associate labels with controls, validate on both client and server, preserve input, explain errors near fields, and announce submission status. Client checks improve experience but are not a security boundary.",
    "followup": "Where should focus move after a failed form submission?"
  },
  {
    "title": "A page has a slow largest-contentful paint. How would you investigate?",
    "topic": "Web performance",
    "concepts": [
      "image",
      "network",
      "render",
      "measure"
    ],
    "reference": "Measure field and lab performance, identify the largest element, inspect network and render delays, then optimize its resource priority, size, caching and blocking dependencies. Re-measure on representative devices.",
    "followup": "Why can lazy-loading the main hero image make performance worse?"
  },
  {
    "title": "How would you decide between local state, context and an external store?",
    "topic": "State management",
    "concepts": [
      "local",
      "context",
      "shared",
      "update"
    ],
    "reference": "Use local state by default, context for appropriate shared dependencies, and a store when update patterns or coordination justify it. Consider subscription granularity, debugging and server-state caching separately.",
    "followup": "Why might frequently changing context cause unnecessary renders?"
  },
  {
    "title": "How would you render user-generated content without introducing XSS?",
    "topic": "Frontend security",
    "concepts": [
      "escape",
      "sanitize",
      "html",
      "untrusted"
    ],
    "reference": "Prefer escaped text. If HTML is required, use a maintained sanitizer with a restrictive policy, validate URL schemes and apply defense-in-depth such as CSP. Avoid injecting untrusted HTML directly.",
    "followup": "Why is input validation alone insufficient to prevent XSS?"
  },
  {
    "title": "What would you test in a shopping-cart component?",
    "topic": "Testing UI",
    "concepts": [
      "interaction",
      "accessibility",
      "edge",
      "integration"
    ],
    "reference": "Test user-visible behavior: adding and removing items, totals, empty states, failures and keyboard operation. Use integration tests for API interactions and avoid tests tied to internal implementation details.",
    "followup": "How would you test an optimistic update that later fails?"
  },
  {
    "title": "What are the trade-offs between client rendering and server rendering?",
    "topic": "Routing",
    "concepts": [
      "server",
      "client",
      "hydration",
      "cache"
    ],
    "reference": "Server rendering can improve initial content delivery and indexing; client rendering supports interactive transitions. Consider hydration cost, caching, personalization and infrastructure rather than assuming one is universally faster.",
    "followup": "What can cause a hydration mismatch?"
  },
  {
    "title": "When would you use cookies, localStorage or IndexedDB?",
    "topic": "Browser storage",
    "concepts": [
      "cookie",
      "localstorage",
      "indexeddb",
      "security"
    ],
    "reference": "Cookies can accompany requests and support HttpOnly server-managed sessions. localStorage is synchronous simple storage; IndexedDB supports larger structured local data asynchronously. Neither script-readable store should be assumed safe from XSS.",
    "followup": "Why should sensitive session tokens not be casually stored in localStorage?"
  },
  {
    "title": "How would you structure a frontend application that several teams maintain?",
    "topic": "Frontend architecture",
    "concepts": [
      "component",
      "contract",
      "test",
      "ownership"
    ],
    "reference": "Organize around coherent features, stable component contracts and explicit ownership. Share accessible primitives, enforce tests and conventions, and avoid premature abstraction. Balance independent delivery with consistency.",
    "followup": "How would you evolve a shared component without breaking existing screens?"
  }
];
banks["Backend Developer"]=[
  {
    "title": "Design a REST endpoint for creating an order. What must happen before success is returned?",
    "topic": "HTTP & APIs",
    "concepts": [
      "validation",
      "authorization",
      "transaction",
      "status"
    ],
    "reference": "Validate input, authenticate and authorize the caller, enforce inventory and pricing rules, persist consistent changes in a transaction and return an appropriate status. Handle duplicate requests safely.",
    "followup": "How would you prevent a retry from creating a second order?"
  },
  {
    "title": "Explain authentication versus authorization in an API.",
    "topic": "Authentication",
    "concepts": [
      "identity",
      "permission",
      "resource",
      "server"
    ],
    "reference": "Authentication establishes identity; authorization decides which actions that identity can perform on a resource. Enforce permission checks server-side on every protected operation and deny by default.",
    "followup": "Why is checking that a user is logged in insufficient for an order-details endpoint?"
  },
  {
    "title": "How would you prevent two customers from buying the last item at the same time?",
    "topic": "Transactions",
    "concepts": [
      "transaction",
      "lock",
      "isolation",
      "atomic"
    ],
    "reference": "Use an atomic conditional update or suitable locking inside a transaction. Check affected rows, choose isolation carefully, and handle contention or retries; a separate read then write is unsafe.",
    "followup": "When would optimistic concurrency be preferable to row locking?"
  },
  {
    "title": "How do you investigate a slow database query?",
    "topic": "Database indexes",
    "concepts": [
      "explain",
      "index",
      "selectivity",
      "query"
    ],
    "reference": "Inspect an execution plan and representative parameters, check scans and joins, then consider indexes, query shape, returned columns and cardinality. Measure write and storage costs before adding indexes.",
    "followup": "Why might a database ignore an available index?"
  },
  {
    "title": "Design caching for a frequently read product catalog.",
    "topic": "Caching",
    "concepts": [
      "cache",
      "invalidation",
      "ttl",
      "consistency"
    ],
    "reference": "Choose cache keys and ownership, a read pattern such as cache-aside, a TTL and invalidation strategy. Define acceptable staleness, protect against stampedes and measure hit rate.",
    "followup": "How would you avoid serving an outdated price during checkout?"
  },
  {
    "title": "When would you move work from an HTTP request to a background queue?",
    "topic": "Queues",
    "concepts": [
      "queue",
      "retry",
      "idempotent",
      "failure"
    ],
    "reference": "Queue slow or deferrable work, persist enough context, make consumers idempotent, and define retry limits and dead-letter handling. Explain delivery semantics and how clients learn job status.",
    "followup": "How would you handle a worker that crashes after performing a side effect?"
  },
  {
    "title": "Compare offset pagination with cursor pagination for a large activity feed.",
    "topic": "Pagination",
    "concepts": [
      "offset",
      "cursor",
      "order",
      "index"
    ],
    "reference": "Offset is simple but can become expensive and unstable under inserts. A cursor uses a stable ordered key, usually with a tie-breaker and supporting index. Define forward/backward behavior and opaque cursor validation.",
    "followup": "Why should a timestamp cursor usually include a unique ID?"
  },
  {
    "title": "How would you protect a public API from abusive request volume?",
    "topic": "Rate limiting",
    "concepts": [
      "rate",
      "limit",
      "identity",
      "distributed"
    ],
    "reference": "Choose limits by user or appropriate client identity, use an algorithm such as token bucket, and coordinate state across replicas. Return clear retry guidance and handle shared IP addresses carefully.",
    "followup": "How would you prevent one expensive endpoint from exhausting all capacity?"
  },
  {
    "title": "A backend intermittently returns errors. What evidence would you collect?",
    "topic": "Observability",
    "concepts": [
      "log",
      "metric",
      "trace",
      "correlation"
    ],
    "reference": "Correlate structured logs, error-rate and latency metrics, and distributed traces with releases and dependencies. Use request IDs while redacting secrets and sensitive payloads.",
    "followup": "How would you identify which downstream service causes a latency spike?"
  },
  {
    "title": "How would you test an API beyond its happy path?",
    "topic": "Testing APIs",
    "concepts": [
      "validation",
      "authorization",
      "integration",
      "failure"
    ],
    "reference": "Cover malformed input, permission boundaries, conflicts, duplicate requests and dependency failures. Use integration tests against representative data and contract tests where services interact.",
    "followup": "How would you test that one user cannot access another user's records?"
  },
  {
    "title": "How would you rename a database field without downtime?",
    "topic": "Schema changes",
    "concepts": [
      "migration",
      "compatibility",
      "backfill",
      "rollback"
    ],
    "reference": "Use an expand-and-contract migration: add compatible schema, deploy code that tolerates both, backfill carefully, switch reads and later remove old fields. Plan observability and rollback boundaries.",
    "followup": "Why can deploying code and a destructive migration together be risky?"
  },
  {
    "title": "What changes when a service runs on multiple instances?",
    "topic": "Distributed systems",
    "concepts": [
      "stateless",
      "shared",
      "concurrency",
      "consistency"
    ],
    "reference": "Avoid assuming process memory is shared, externalize necessary state, coordinate concurrent writes and understand consistency requirements. Use load balancing, health checks and safe retry behavior.",
    "followup": "Why does an in-memory session store fail after horizontal scaling?"
  },
  {
    "title": "How would you build a reliable webhook receiver?",
    "topic": "Webhooks",
    "concepts": [
      "signature",
      "idempotent",
      "replay",
      "queue"
    ],
    "reference": "Verify signatures over the raw body, check timestamp or replay constraints, deduplicate events, acknowledge promptly after durable acceptance and process safely in the background.",
    "followup": "How should the receiver handle events delivered out of order?"
  },
  {
    "title": "How would you safely accept user-uploaded files?",
    "topic": "File uploads",
    "concepts": [
      "size",
      "type",
      "storage",
      "authorization"
    ],
    "reference": "Enforce size and allowed format limits, inspect content rather than trusting extensions, use isolated storage and generated names, and authorize access. Consider malware scanning and safe download headers.",
    "followup": "Why should uploaded files not be served as executable content?"
  },
  {
    "title": "Design the backend of a URL shortener and discuss its bottlenecks.",
    "topic": "System design",
    "concepts": [
      "identifier",
      "collision",
      "redirect",
      "scale"
    ],
    "reference": "Define creation and redirect APIs, generate unique identifiers, index lookups and handle collisions. Consider hot-link caching, abuse controls, expiration and durability. Scale based on measured read/write patterns.",
    "followup": "How would you handle a suddenly viral short link?"
  }
];
banks["Mobile Application Developer"]=[
  {
    "title": "How should a mobile app behave when it moves into the background and returns?",
    "topic": "Application lifecycle",
    "concepts": [
      "lifecycle",
      "state",
      "background",
      "restore"
    ],
    "reference": "Respect lifecycle callbacks, pause unnecessary work, persist important state and restore the screen safely. Assume the operating system may terminate the process and restrict background execution.",
    "followup": "How would you restore an unfinished form after the process is killed?"
  },
  {
    "title": "How would you design navigation that supports back behavior and deep links?",
    "topic": "UI & navigation",
    "concepts": [
      "navigation",
      "back",
      "deep link",
      "state"
    ],
    "reference": "Use a predictable navigation stack, validate deep-link parameters, restore appropriate state and handle authentication before opening protected screens. Follow platform back conventions.",
    "followup": "What should happen when a deep link points to a deleted item?"
  },
  {
    "title": "How would you support different screen sizes and text scaling?",
    "topic": "Responsive mobile UI",
    "concepts": [
      "layout",
      "adaptive",
      "text",
      "accessibility"
    ],
    "reference": "Use adaptive constraints and density-aware dimensions, allow text reflow, respect safe areas and test large font settings and orientation. Avoid fixed heights that clip content.",
    "followup": "How would you adapt the same screen from a phone to a tablet?"
  },
  {
    "title": "Why must network and database work avoid blocking the main thread?",
    "topic": "Async work",
    "concepts": [
      "main thread",
      "async",
      "responsiveness",
      "cancellation"
    ],
    "reference": "The main thread handles UI and input; blocking it causes jank or unresponsiveness. Use suitable asynchronous/background mechanisms, return UI updates safely and cancel obsolete work.",
    "followup": "How would you prevent a completed request from updating a destroyed screen?"
  },
  {
    "title": "Design a notes app that works without an internet connection.",
    "topic": "Offline-first data",
    "concepts": [
      "local",
      "sync",
      "conflict",
      "queue"
    ],
    "reference": "Persist notes locally, queue changes durably, synchronize when connectivity returns and define conflict resolution. Surface pending/error states and use stable IDs and idempotent requests.",
    "followup": "How would you merge edits to the same note from two devices?"
  },
  {
    "title": "How would you separate UI, business logic and data access in a mobile app?",
    "topic": "Mobile architecture",
    "concepts": [
      "viewmodel",
      "repository",
      "state",
      "test"
    ],
    "reference": "Use clear responsibilities, observable UI state, a testable logic layer and repositories that hide data sources. Choose architecture proportional to complexity and handle lifecycle ownership.",
    "followup": "How would you unit-test a screen without a real network connection?"
  },
  {
    "title": "Where would you store credentials or sensitive tokens on a phone?",
    "topic": "Secure storage",
    "concepts": [
      "keystore",
      "keychain",
      "encryption",
      "token"
    ],
    "reference": "Use platform-backed secure storage such as Keychain or Keystore-backed facilities, minimize retained secrets and handle expiry and logout. Avoid plain preferences and logging credentials.",
    "followup": "What should happen to locally stored tokens when a user signs out?"
  },
  {
    "title": "How would you request camera or location access responsibly?",
    "topic": "Permissions",
    "concepts": [
      "permission",
      "purpose",
      "denial",
      "minimal"
    ],
    "reference": "Request the minimum permission at the moment its purpose is clear, explain the benefit, and handle denial or later revocation without breaking unrelated features. Prefer reduced scope when sufficient.",
    "followup": "How would your screen behave if location is denied permanently?"
  },
  {
    "title": "A scrolling list stutters. How would you diagnose it?",
    "topic": "Performance",
    "concepts": [
      "profiling",
      "recycle",
      "image",
      "main thread"
    ],
    "reference": "Profile frame times and main-thread work, use efficient list reuse, avoid expensive repeated layout and decoding, and size/cache images appropriately. Verify on representative low-end devices.",
    "followup": "How could loading full-resolution photos affect scrolling performance?"
  },
  {
    "title": "How would you reduce an app's battery and data usage?",
    "topic": "Battery & networking",
    "concepts": [
      "batch",
      "cache",
      "background",
      "location"
    ],
    "reference": "Batch work, cache suitable data, avoid unnecessary polling and use platform scheduling. Reduce location precision/frequency to the actual need and measure energy consumption.",
    "followup": "When would push notifications be preferable to polling?"
  },
  {
    "title": "Describe a reliable push-notification flow from server to app.",
    "topic": "Push notifications",
    "concepts": [
      "token",
      "permission",
      "payload",
      "refresh"
    ],
    "reference": "Register with the platform push service, associate and refresh device tokens securely, respect permission and preferences, and route notification taps safely. Do not treat push delivery as guaranteed.",
    "followup": "How should an app recover if it missed a notification?"
  },
  {
    "title": "How should a mobile app handle intermittent network failures?",
    "topic": "API reliability",
    "concepts": [
      "timeout",
      "retry",
      "backoff",
      "idempotent"
    ],
    "reference": "Use timeouts, bounded exponential backoff with jitter and clear retry states. Retry only safe operations or use idempotency keys. Do not assume connectivity detection proves an API is reachable.",
    "followup": "How would you prevent duplicate payments after a connection timeout?"
  },
  {
    "title": "What belongs in unit, integration and device tests?",
    "topic": "Testing mobile apps",
    "concepts": [
      "unit",
      "integration",
      "device",
      "lifecycle"
    ],
    "reference": "Test logic cheaply in unit tests, data and platform boundaries in integration tests, and critical flows on devices. Include lifecycle, permission, offline and accessibility cases.",
    "followup": "Which bugs might only appear on a real device?"
  },
  {
    "title": "How would you choose between native and cross-platform development?",
    "topic": "Native vs cross-platform",
    "concepts": [
      "platform",
      "performance",
      "team",
      "trade-off"
    ],
    "reference": "Compare required platform APIs, UI behavior, performance constraints, team skills and maintenance cost. Validate difficult features with a prototype instead of assuming shared code is always cheaper.",
    "followup": "What might justify writing a native module inside a cross-platform app?"
  },
  {
    "title": "How would you release a mobile update safely?",
    "topic": "Release management",
    "concepts": [
      "staged",
      "crash",
      "compatibility",
      "rollback"
    ],
    "reference": "Test signed release builds, preserve API/data compatibility, roll out gradually and watch crash and performance metrics. Use feature flags where appropriate; store distribution makes rollback less immediate than on the web.",
    "followup": "How would your backend support users who have not updated the app?"
  }
];
banks["Cybersecurity Analyst"]=[
  {
    "title": "Explain confidentiality, integrity and availability using one real system.",
    "topic": "Security fundamentals",
    "concepts": [
      "confidentiality",
      "integrity",
      "availability",
      "control"
    ],
    "reference": "Confidentiality prevents unauthorized disclosure, integrity prevents unauthorized changes, and availability supports reliable access. Map each to practical controls and consider their trade-offs.",
    "followup": "How could a control improve confidentiality but hurt availability?"
  },
  {
    "title": "How would you threat-model a new customer portal?",
    "topic": "Threat modeling",
    "concepts": [
      "asset",
      "trust",
      "threat",
      "mitigation"
    ],
    "reference": "Identify assets, entry points, data flows and trust boundaries, enumerate plausible threats, prioritize by impact and likelihood, and map mitigations and verification steps.",
    "followup": "Which risks would you prioritize before the first release?"
  },
  {
    "title": "How would you apply least privilege to service accounts?",
    "topic": "Least privilege",
    "concepts": [
      "permission",
      "scope",
      "rotation",
      "audit"
    ],
    "reference": "Grant only required actions and resources, separate identities by workload, avoid shared credentials and review access regularly. Use short-lived credentials where possible and audit sensitive operations.",
    "followup": "How would you discover an overprivileged service account?"
  },
  {
    "title": "A user reports a suspicious email. How would you investigate safely?",
    "topic": "Phishing response",
    "concepts": [
      "header",
      "link",
      "attachment",
      "report"
    ],
    "reference": "Preserve the message, examine headers and indicators using approved tools, avoid executing attachments or visiting links on a normal workstation, and follow reporting and containment procedures.",
    "followup": "What additional actions are needed if the user entered credentials?"
  },
  {
    "title": "What would you do first after signs of a compromised workstation?",
    "topic": "Incident response",
    "concepts": [
      "contain",
      "evidence",
      "scope",
      "recovery"
    ],
    "reference": "Validate the alert, coordinate containment while preserving evidence, determine scope, eradicate the cause and recover safely. Document decisions and follow the incident-response plan.",
    "followup": "When might powering off a device destroy useful evidence?"
  },
  {
    "title": "How would you investigate a spike in failed login attempts?",
    "topic": "Log analysis",
    "concepts": [
      "baseline",
      "source",
      "account",
      "correlation"
    ],
    "reference": "Compare against baseline, group by source and target accounts, correlate successes and other telemetry, and consider legitimate causes. Escalate or contain based on evidence, not volume alone.",
    "followup": "How would password spraying differ from brute forcing one account?"
  },
  {
    "title": "What can a firewall do, and what can it not guarantee?",
    "topic": "Network security",
    "concepts": [
      "traffic",
      "rule",
      "segmentation",
      "application"
    ],
    "reference": "A firewall enforces traffic policy at supported layers. Use restrictive rules and segmentation, but recognize permitted traffic, compromised endpoints and application flaws can still cause incidents.",
    "followup": "Why is an internal network not automatically trustworthy?"
  },
  {
    "title": "Explain what HTTPS protects and what it does not.",
    "topic": "TLS",
    "concepts": [
      "encryption",
      "certificate",
      "integrity",
      "endpoint"
    ],
    "reference": "TLS protects data in transit and authenticates the server through certificate validation. It does not guarantee the site is trustworthy, secure compromised endpoints or fix application authorization.",
    "followup": "Why should a client never ignore certificate errors in production?"
  },
  {
    "title": "How should a service store user passwords?",
    "topic": "Password security",
    "concepts": [
      "hash",
      "salt",
      "adaptive",
      "rate limit"
    ],
    "reference": "Store salted adaptive password hashes using a suitable password-hashing algorithm, tune cost and protect reset flows. Never use reversible encryption as the standard password-storage method; rate-limit authentication.",
    "followup": "Why are fast general-purpose hashes unsuitable for password storage?"
  },
  {
    "title": "How would you prioritize a backlog of vulnerabilities?",
    "topic": "Vulnerability management",
    "concepts": [
      "exposure",
      "impact",
      "exploitability",
      "asset"
    ],
    "reference": "Consider severity alongside internet exposure, exploitability, asset importance and existing controls. Assign owners and deadlines, verify fixes and document accepted risk.",
    "followup": "Why might a lower-severity issue deserve faster remediation?"
  },
  {
    "title": "How would you prevent SQL injection in a search endpoint?",
    "topic": "SQL injection prevention",
    "concepts": [
      "parameter",
      "query",
      "validation",
      "privilege"
    ],
    "reference": "Use parameterized queries for values, allowlist any dynamic identifiers, validate inputs and restrict database privileges. Do not build SQL by concatenating untrusted strings.",
    "followup": "Can a parameter placeholder safely substitute a table name?"
  },
  {
    "title": "How would you test object-level authorization in an application you are authorized to assess?",
    "topic": "Access control testing",
    "concepts": [
      "authorization",
      "object",
      "user",
      "server"
    ],
    "reference": "Use scoped test accounts with different ownership and roles, verify server-side access checks for each action, and document results without accessing unrelated real data.",
    "followup": "Why do unpredictable object IDs not replace authorization?"
  },
  {
    "title": "How would you investigate an accidentally public storage bucket?",
    "topic": "Cloud security",
    "concepts": [
      "access",
      "log",
      "exposure",
      "remediation"
    ],
    "reference": "Confirm scope with approved access, restrict the exposure, preserve and review access logs, determine affected data and rotate any exposed secrets. Follow notification and evidence-handling procedures.",
    "followup": "How would you prevent the same configuration from recurring?"
  },
  {
    "title": "How would you reduce false positives in a detection rule?",
    "topic": "Security monitoring",
    "concepts": [
      "baseline",
      "context",
      "tuning",
      "coverage"
    ],
    "reference": "Study labeled alerts, enrich with context, tune thresholds or logic and validate against representative benign and malicious cases. Track coverage so reducing noise does not hide real threats.",
    "followup": "How would you measure whether a rule change harmed detection?"
  },
  {
    "title": "How would you explain a technical security risk to a business owner?",
    "topic": "Risk communication",
    "concepts": [
      "impact",
      "likelihood",
      "mitigation",
      "priority"
    ],
    "reference": "Describe the asset, plausible scenario, likelihood and business impact in plain language. Offer actionable mitigations with cost and residual risk, and distinguish evidence from uncertainty.",
    "followup": "How would you explain residual risk after a fix?"
  }
];
banks["AI / ML Engineer"].push(...[
  {
    "title": "How would you split time-series data for model evaluation?",
    "topic": "Data splitting",
    "concepts": [
      "time",
      "leakage",
      "validation",
      "window"
    ],
    "reference": "Preserve temporal order, train on earlier data and evaluate on later periods using rolling or expanding windows. Fit preprocessing only on training data and account for forecasting horizon.",
    "followup": "Why can random splitting give overly optimistic forecasting results?"
  },
  {
    "title": "How would you handle missing values and categorical features in a pipeline?",
    "topic": "Feature engineering",
    "concepts": [
      "imputation",
      "encoding",
      "pipeline",
      "leakage"
    ],
    "reference": "Choose treatment from data meaning, fit imputers and encoders on training folds, handle unseen categories and keep transforms in a reproducible pipeline. Evaluate impact instead of assuming one encoding is best.",
    "followup": "How would you avoid target leakage with target encoding?"
  },
  {
    "title": "Explain the bias-variance trade-off with an example.",
    "topic": "Bias & variance",
    "concepts": [
      "bias",
      "variance",
      "underfitting",
      "overfitting"
    ],
    "reference": "Simple models may underfit through high bias, while flexible models may overfit through high variance. Compare training and validation behavior and adjust complexity or regularization with representative evaluation.",
    "followup": "Can collecting more data fix a severely underfitting model?"
  },
  {
    "title": "When would you prefer a linear model over a tree ensemble?",
    "topic": "Model selection",
    "concepts": [
      "interpretability",
      "baseline",
      "nonlinear",
      "validation"
    ],
    "reference": "Use a linear model as a strong baseline when relationships and constraints fit. Compare held-out performance, interpretability, latency and maintenance against ensembles that capture nonlinear interactions.",
    "followup": "How would you fairly compare both models?"
  },
  {
    "title": "Explain gradient descent and the role of the learning rate.",
    "topic": "Optimization",
    "concepts": [
      "gradient",
      "loss",
      "learning rate",
      "convergence"
    ],
    "reference": "Compute gradients of the loss and update parameters in a descent direction. Learning rate controls step size; overly large steps can diverge while small steps converge slowly. Monitor validation as well as training loss.",
    "followup": "What would you investigate if loss becomes NaN during training?"
  },
  {
    "title": "How would you choose and evaluate clusters when no labels exist?",
    "topic": "Clustering",
    "concepts": [
      "silhouette",
      "stability",
      "scaling",
      "business"
    ],
    "reference": "Scale relevant features, compare internal metrics and cluster stability, inspect profiles and assess usefulness for the task. Internal scores alone do not establish meaningful segmentation.",
    "followup": "Why does feature scaling matter for K-means?"
  },
  {
    "title": "Explain PCA and one limitation of using it before modeling.",
    "topic": "Dimensionality reduction",
    "concepts": [
      "variance",
      "component",
      "scaling",
      "linear"
    ],
    "reference": "PCA finds orthogonal directions capturing variance. Center and often scale features, fit on training data and choose components using validation. High variance need not mean predictive importance; PCA is linear.",
    "followup": "Why could discarding a low-variance component hurt classification?"
  },
  {
    "title": "What does it mean for a classifier to be well calibrated?",
    "topic": "Model calibration",
    "concepts": [
      "probability",
      "calibration",
      "reliability",
      "validation"
    ],
    "reference": "Predictions near a probability should have a similar empirical outcome rate. Inspect reliability diagrams and proper scoring rules, and fit calibration on held-out data. Discrimination and calibration are distinct.",
    "followup": "Can a model have high accuracy but poorly calibrated probabilities?"
  },
  {
    "title": "How would you build and evaluate a recommendation system?",
    "topic": "Recommendation systems",
    "concepts": [
      "collaborative",
      "content",
      "cold start",
      "ranking"
    ],
    "reference": "Start with a baseline, consider collaborative or content signals, address cold start and evaluate ranking metrics with leakage-safe splits. Validate online outcomes and consider diversity and exposure bias.",
    "followup": "How would you recommend items to a new user?"
  },
  {
    "title": "How would you investigate unequal error rates across user groups?",
    "topic": "Responsible ML",
    "concepts": [
      "subgroup",
      "metric",
      "representation",
      "uncertainty"
    ],
    "reference": "Define relevant harms and metrics, examine data representation and subgroup errors with uncertainty, and investigate causes. Evaluate mitigations and trade-offs rather than assuming aggregate accuracy proves fairness.",
    "followup": "Why can tiny subgroup samples lead to misleading conclusions?"
  }
]);
banks["Full-stack Developer"].push(...[
  {
    "title": "How would you keep frontend and backend data contracts consistent?",
    "topic": "Client-server contracts",
    "concepts": [
      "schema",
      "validation",
      "version",
      "contract"
    ],
    "reference": "Define explicit request and response schemas, validate at boundaries and use contract tests or generated types where appropriate. Plan backward-compatible evolution and clear error formats.",
    "followup": "What should happen when an older client sends a removed field?"
  },
  {
    "title": "How would you implement roles across the UI and API?",
    "topic": "End-to-end authorization",
    "concepts": [
      "role",
      "permission",
      "server",
      "resource"
    ],
    "reference": "The UI can hide unavailable actions, but the API must enforce resource-level permissions. Model roles explicitly, deny by default and test unauthorized requests directly.",
    "followup": "Why is hiding an admin button insufficient?"
  },
  {
    "title": "How would you implement an optimistic update for a task list?",
    "topic": "Optimistic updates",
    "concepts": [
      "optimistic",
      "rollback",
      "pending",
      "conflict"
    ],
    "reference": "Update the visible state immediately, track pending work, reconcile the server response and roll back or explain failures. Handle concurrent edits and repeated requests.",
    "followup": "How would you avoid overwriting a newer edit with an older response?"
  },
  {
    "title": "Design search with autocomplete across frontend and backend.",
    "topic": "Search",
    "concepts": [
      "debounce",
      "index",
      "cancel",
      "pagination"
    ],
    "reference": "Debounce appropriate input, cancel or ignore stale responses, index searchable data and paginate results. Consider access control, empty states and measuring query latency.",
    "followup": "How would you stop slow old results from replacing a newer search?"
  },
  {
    "title": "Design a profile-photo upload flow.",
    "topic": "Uploads",
    "concepts": [
      "validation",
      "storage",
      "authorization",
      "size"
    ],
    "reference": "Validate size and content server-side, authorize the user, use isolated storage and generated keys, then update metadata safely. Provide upload progress, failure recovery and safe image delivery.",
    "followup": "How would you clean up an uploaded file if saving its metadata fails?"
  },
  {
    "title": "When would you use polling, server-sent events or WebSockets?",
    "topic": "Real-time updates",
    "concepts": [
      "polling",
      "sse",
      "websocket",
      "reconnect"
    ],
    "reference": "Match directionality and latency needs: polling is simple, SSE is server-to-client streaming, and WebSockets are bidirectional. Plan reconnects, authentication, ordering and capacity.",
    "followup": "How would a client recover events missed during disconnection?"
  },
  {
    "title": "How should a full-stack app handle errors consistently?",
    "topic": "Error handling",
    "concepts": [
      "status",
      "message",
      "logging",
      "retry"
    ],
    "reference": "Return structured API errors with suitable status codes, show actionable UI messages and preserve input. Correlate logs without leaking internal details and retry only safe operations.",
    "followup": "How would you distinguish validation errors from temporary service failures?"
  },
  {
    "title": "How would you manage configuration and secrets across environments?",
    "topic": "Deployment configuration",
    "concepts": [
      "secret",
      "environment",
      "server",
      "rotation"
    ],
    "reference": "Separate configuration from code, keep secrets server-side in managed storage, scope access and plan rotation. Understand which frontend build variables become publicly readable.",
    "followup": "Why is a secret prefixed for frontend exposure no longer secret?"
  },
  {
    "title": "How would you handle two users editing the same document?",
    "topic": "Data consistency",
    "concepts": [
      "version",
      "conflict",
      "concurrency",
      "merge"
    ],
    "reference": "Use versions or conditional writes to detect conflicts, then reject, merge or resolve according to product rules. For live collaboration, consider a suitable shared editing model.",
    "followup": "Why can last-write-wins silently lose useful work?"
  },
  {
    "title": "Design a small appointment-booking application end to end.",
    "topic": "System architecture",
    "concepts": [
      "availability",
      "transaction",
      "timezone",
      "authorization"
    ],
    "reference": "Define UI states and APIs, model availability and bookings, use transactional conflict prevention, store time consistently and enforce ownership. Include cancellation, retries and notifications.",
    "followup": "How would you prevent double-booking across concurrent requests?"
  }
]);
banks["Data Analyst"].push(...[
  {
    "title": "How would you calculate monthly revenue without double-counting orders?",
    "topic": "Aggregation",
    "concepts": [
      "grain",
      "join",
      "aggregate",
      "duplicate"
    ],
    "reference": "Define the data grain and revenue rules, inspect join cardinality, aggregate at the correct level and reconcile totals. Handle refunds and time boundaries explicitly.",
    "followup": "Why can joining order lines to payments inflate total revenue?"
  },
  {
    "title": "When would you use a SQL window function instead of GROUP BY?",
    "topic": "Window functions",
    "concepts": [
      "window",
      "partition",
      "order",
      "row"
    ],
    "reference": "Window functions compute over related rows while retaining individual records; GROUP BY collapses rows. Specify partition, ordering and frame as needed for rankings or running totals.",
    "followup": "How do ROW_NUMBER and RANK differ when values tie?"
  },
  {
    "title": "How would you identify and treat duplicate customer records?",
    "topic": "Data cleaning",
    "concepts": [
      "duplicate",
      "key",
      "match",
      "validation"
    ],
    "reference": "Define what a duplicate means, examine stable IDs and normalized attributes, and use cautious matching rules. Preserve auditability and validate merges to avoid combining different people.",
    "followup": "Why is matching customers by name alone unreliable?"
  },
  {
    "title": "How would you decide whether an outlier should be removed?",
    "topic": "Outliers",
    "concepts": [
      "outlier",
      "context",
      "error",
      "sensitivity"
    ],
    "reference": "Inspect source and context, distinguish data errors from valid extremes and assess analytical impact. Correct known errors and use robust methods or sensitivity analysis instead of automatic deletion.",
    "followup": "When can a valid outlier be the most important observation?"
  },
  {
    "title": "How would you measure user retention by acquisition cohort?",
    "topic": "Cohort analysis",
    "concepts": [
      "cohort",
      "retention",
      "denominator",
      "period"
    ],
    "reference": "Define acquisition and return events, group users by start period and compare retention at equal ages. Use consistent denominators and account for incomplete observation windows.",
    "followup": "Why should a new cohort not be compared to an older cohort at unequal ages?"
  },
  {
    "title": "How would you investigate a drop between signup and activation?",
    "topic": "Funnel analysis",
    "concepts": [
      "funnel",
      "event",
      "segment",
      "conversion"
    ],
    "reference": "Define ordered events and time windows, validate tracking, measure conversion and segment by relevant attributes. Investigate where and for whom users drop off before proposing changes.",
    "followup": "How could a tracking change create an apparent funnel drop?"
  },
  {
    "title": "Explain a confidence interval to a nontechnical colleague.",
    "topic": "Statistical uncertainty",
    "concepts": [
      "estimate",
      "uncertainty",
      "sample",
      "method"
    ],
    "reference": "A confidence interval expresses uncertainty from a procedure whose repeated-sampling coverage is specified. Explain the plausible range and assumptions without claiming it gives a probability that a fixed parameter lies inside this observed interval.",
    "followup": "Why do smaller samples usually produce wider intervals?"
  },
  {
    "title": "How would you investigate a correlation before recommending action?",
    "topic": "Correlation",
    "concepts": [
      "confounding",
      "causation",
      "experiment",
      "trend"
    ],
    "reference": "Check data quality, confounders, timing and shared trends. Correlation alone cannot establish causation; use experiments or justified causal designs when a causal decision is needed.",
    "followup": "How could seasonality create a misleading correlation?"
  },
  {
    "title": "What makes a dashboard useful for operational decisions?",
    "topic": "Dashboard design",
    "concepts": [
      "metric",
      "decision",
      "filter",
      "definition"
    ],
    "reference": "Choose metrics tied to decisions, define them clearly, provide relevant comparisons and useful filters, and display freshness and uncertainty where needed. Avoid clutter and misleading axes.",
    "followup": "How would you handle stakeholders requesting dozens of extra charts?"
  },
  {
    "title": "How would you build a simple sales forecast and evaluate it?",
    "topic": "Forecasting",
    "concepts": [
      "seasonality",
      "baseline",
      "time",
      "error"
    ],
    "reference": "Inspect trends and seasonality, start with naive baselines, use chronological evaluation and appropriate error measures. Include uncertainty and explain limits under structural changes.",
    "followup": "Why can percentage error metrics fail when actual sales are near zero?"
  }
]);

// Extended practice sessions: 25 distinct main questions per domain.
banks["Frontend Developer"].push(...[
  {
    "title": "How would you test a modal dialog for accessibility?",
    "topic": "Accessibility testing",
    "concepts": [
      "focus",
      "keyboard",
      "label",
      "restore"
    ],
    "reference": "Check its accessible name, initial focus, keyboard behavior, focus containment while modal and restoration on close. Test with assistive technology and avoid hiding focused content.",
    "followup": "What should happen if the element that opened the dialog no longer exists?"
  },
  {
    "title": "How would you resolve conflicting styles without adding repeated important declarations?",
    "topic": "CSS cascade",
    "concepts": [
      "cascade",
      "specificity",
      "inheritance",
      "layer"
    ],
    "reference": "Inspect computed styles and rule origins, understand specificity and source order, and simplify selectors or use intentional cascade layers. Distinguish inheritance from directly applied rules.",
    "followup": "Why might a lower-specificity rule win in a different cascade layer?"
  },
  {
    "title": "How do discriminated unions help model loading and error states?",
    "topic": "TypeScript",
    "concepts": [
      "union",
      "discriminant",
      "narrowing",
      "exhaustive"
    ],
    "reference": "Represent each state as a variant with a distinguishing literal field. Narrow before accessing variant-specific data and use exhaustive handling to prevent impossible combinations.",
    "followup": "How could separate loading and error booleans create contradictory states?"
  },
  {
    "title": "How would you investigate memory growth in a single-page application?",
    "topic": "Memory leaks",
    "concepts": [
      "listener",
      "cleanup",
      "heap",
      "reference"
    ],
    "reference": "Reproduce repeated navigation, compare heap snapshots, find retained objects and inspect subscriptions, timers and listeners. Clean up ownership boundaries and verify memory stabilizes.",
    "followup": "How can a detached DOM node remain in memory?"
  },
  {
    "title": "What changes when a UI must support multiple languages?",
    "topic": "Internationalization",
    "concepts": [
      "locale",
      "plural",
      "format",
      "layout"
    ],
    "reference": "Externalize messages, use locale-aware pluralization and date/number formatting, allow expansion and support text direction. Avoid concatenating translated fragments.",
    "followup": "How would you handle right-to-left layout without reversing every element?"
  },
  {
    "title": "How would you serve responsive images without layout shifts?",
    "topic": "Images",
    "concepts": [
      "srcset",
      "sizes",
      "dimensions",
      "format"
    ],
    "reference": "Supply appropriate responsive sources and sizes, reserve space using dimensions or aspect ratio, choose efficient formats and prioritize critical images. Measure quality and transfer cost.",
    "followup": "How is the sizes attribute different from CSS width?"
  },
  {
    "title": "How would you build keyboard-accessible autocomplete?",
    "topic": "Search UX",
    "concepts": [
      "combobox",
      "keyboard",
      "selection",
      "announcement"
    ],
    "reference": "Use appropriate combobox semantics and clearly distinguish active suggestion from committed value. Support navigation, dismissal and selection, and announce useful changes without excessive chatter.",
    "followup": "What should Escape do while suggestions are open?"
  },
  {
    "title": "How would you prevent a component failure from blanking the whole application?",
    "topic": "Error recovery",
    "concepts": [
      "boundary",
      "fallback",
      "logging",
      "retry"
    ],
    "reference": "Place error boundaries around meaningful UI regions, provide useful fallbacks and recovery, and report failures. Handle asynchronous and event-handler errors separately as needed.",
    "followup": "Why does an error boundary not replace API error handling?"
  },
  {
    "title": "How would you reduce JavaScript shipped on the first page load?",
    "topic": "Bundle optimization",
    "concepts": [
      "bundle",
      "split",
      "lazy",
      "measure"
    ],
    "reference": "Analyze bundle composition, remove unnecessary runtime work, split along useful routes/features and defer noncritical code. Measure loading and interaction costs to avoid waterfall regressions.",
    "followup": "When could excessive code splitting hurt performance?"
  },
  {
    "title": "How would you make a reusable button component flexible without excessive props?",
    "topic": "Design systems",
    "concepts": [
      "semantic",
      "variant",
      "composition",
      "accessibility"
    ],
    "reference": "Preserve native button behavior, expose a small set of meaningful variants and use composition for content. Document keyboard, disabled and loading states and avoid ambiguous combinations.",
    "followup": "How should a loading button prevent duplicate submissions?"
  }
]);
banks["Backend Developer"].push(...[
  {
    "title": "Why use a database connection pool and how would you size it?",
    "topic": "Connection pooling",
    "concepts": [
      "pool",
      "concurrency",
      "limit",
      "timeout"
    ],
    "reference": "Reuse connections to avoid setup cost, bound concurrency and respect database limits across all service instances. Measure waiting and query duration and set sensible timeouts.",
    "followup": "Why can adding more application replicas exhaust database connections?"
  },
  {
    "title": "How would you implement idempotency keys for a payment request?",
    "topic": "Idempotency",
    "concepts": [
      "key",
      "atomic",
      "result",
      "expiry"
    ],
    "reference": "Associate a key with the caller and request fingerprint, reserve it atomically, persist the outcome and replay the same result. Handle in-progress duplicates and define retention.",
    "followup": "What should happen if the same key is reused with a different amount?"
  },
  {
    "title": "When would you extract a module into a separate service?",
    "topic": "Service boundaries",
    "concepts": [
      "ownership",
      "coupling",
      "deployment",
      "complexity"
    ],
    "reference": "Consider independent ownership, scaling and release needs against network, consistency and operational complexity. Start with clear module boundaries and avoid distribution without a concrete benefit.",
    "followup": "How could a shared database undermine independent service ownership?"
  },
  {
    "title": "How would you manage timeouts across a chain of services?",
    "topic": "Timeout budgets",
    "concepts": [
      "deadline",
      "timeout",
      "cancellation",
      "retry"
    ],
    "reference": "Propagate deadlines, allocate downstream budgets, cancel obsolete work and limit retries within the total request budget. Avoid multiplying retries across layers.",
    "followup": "Why can retries make an overloaded service fail more severely?"
  },
  {
    "title": "How would you process events that may arrive twice or out of order?",
    "topic": "Message ordering",
    "concepts": [
      "deduplication",
      "version",
      "ordering",
      "idempotent"
    ],
    "reference": "Use stable event IDs, idempotent handlers and suitable ordering or version checks per entity. Define how late events and gaps are handled instead of assuming global order.",
    "followup": "How would you detect a missing event in an entity stream?"
  },
  {
    "title": "When would you normalize or denormalize data?",
    "topic": "Database modeling",
    "concepts": [
      "normalization",
      "duplication",
      "consistency",
      "query"
    ],
    "reference": "Normalize to reduce redundant updates and protect consistency; denormalize selectively for measured access patterns. Define ownership and synchronization for any duplicated data.",
    "followup": "How would you keep a denormalized count accurate?"
  },
  {
    "title": "How should a service shut down during a deployment?",
    "topic": "Graceful shutdown",
    "concepts": [
      "drain",
      "request",
      "signal",
      "deadline"
    ],
    "reference": "Stop accepting new work, withdraw readiness, drain in-flight requests within a deadline and close resources. Ensure interrupted background jobs can be recovered safely.",
    "followup": "What should happen to a job that exceeds the shutdown deadline?"
  },
  {
    "title": "How would you evolve an API without breaking existing clients?",
    "topic": "API versioning",
    "concepts": [
      "compatibility",
      "contract",
      "deprecation",
      "version"
    ],
    "reference": "Prefer compatible additions, define response contracts, monitor usage and communicate deprecations. Introduce versions when changes cannot preserve semantics and test old clients.",
    "followup": "Can adding a new enum value break a client?"
  },
  {
    "title": "How do liveness and readiness checks serve different purposes?",
    "topic": "Health checks",
    "concepts": [
      "liveness",
      "readiness",
      "traffic",
      "restart"
    ],
    "reference": "Liveness asks whether a process should be restarted; readiness asks whether it can serve traffic. Keep checks intentional so a downstream outage does not trigger a restart storm.",
    "followup": "Should every dependency failure make a liveness check fail?"
  },
  {
    "title": "How would you implement deletion and retention policies for user records?",
    "topic": "Data retention",
    "concepts": [
      "retention",
      "deletion",
      "backup",
      "audit"
    ],
    "reference": "Define scope and deadlines, remove or anonymize data across primary stores and derived systems, account for backups and log only necessary audit evidence. Verify deletion jobs and failure recovery.",
    "followup": "How would you prevent deleted data from reappearing after a restore?"
  }
]);
banks["Mobile Application Developer"].push(...[
  {
    "title": "How would you migrate a local database without losing user data?",
    "topic": "Local databases",
    "concepts": [
      "migration",
      "version",
      "transaction",
      "test"
    ],
    "reference": "Version the schema, provide incremental migration paths, use transactions where supported and test upgrades from supported historical versions with real data shapes.",
    "followup": "What should happen if migration fails halfway through?"
  },
  {
    "title": "How would you make a mobile form usable with screen readers?",
    "topic": "Mobile accessibility",
    "concepts": [
      "label",
      "focus",
      "target",
      "announcement"
    ],
    "reference": "Use meaningful labels and reading order, adequate touch targets and clear error announcements. Test platform assistive tools, large text and alternative input methods.",
    "followup": "Why might an icon-only control be unusable without an accessible name?"
  },
  {
    "title": "How would you display hundreds of photos without exhausting memory?",
    "topic": "Image loading",
    "concepts": [
      "thumbnail",
      "cache",
      "decode",
      "reuse"
    ],
    "reference": "Request appropriately sized images, decode off the UI thread where possible, use bounded caches and recycle list items. Cancel obsolete loads and inspect memory under rapid scrolling.",
    "followup": "Why can compressed image file size underestimate memory usage?"
  },
  {
    "title": "How would you schedule a file sync that survives the app closing?",
    "topic": "Background work",
    "concepts": [
      "scheduler",
      "constraint",
      "persistence",
      "retry"
    ],
    "reference": "Use platform-managed background work with durable state, suitable network/power constraints and safe retries. Respect scheduling limits and do not promise immediate execution.",
    "followup": "When is a foreground user-visible task more appropriate?"
  },
  {
    "title": "How would you validate a deep link that opens a protected screen?",
    "topic": "Deep-link security",
    "concepts": [
      "validation",
      "authorization",
      "parameter",
      "redirect"
    ],
    "reference": "Validate routes and parameters, authenticate when needed and authorize the referenced resource server-side. Reject untrusted redirects and never treat possession of a link as permission.",
    "followup": "How would you handle a link pointing to another user's private record?"
  },
  {
    "title": "How would you debug a crash affecting only one device family?",
    "topic": "Crash diagnosis",
    "concepts": [
      "crash",
      "symbol",
      "device",
      "reproduce"
    ],
    "reference": "Collect privacy-conscious crash reports with symbols and relevant environment context, group by signature and reproduce on affected hardware or configuration. Check lifecycle and resource assumptions.",
    "followup": "What information is needed to interpret an obfuscated stack trace?"
  },
  {
    "title": "How do transient UI state and durable application data differ?",
    "topic": "State restoration",
    "concepts": [
      "transient",
      "persist",
      "restore",
      "source"
    ],
    "reference": "Keep short-lived presentation state distinct from durable user records. Persist what must survive process death and restore from an authoritative source without replaying unintended actions.",
    "followup": "Should restoring a checkout screen automatically resubmit payment?"
  },
  {
    "title": "How would you handle an unreliable connection to a Bluetooth accessory?",
    "topic": "Bluetooth integration",
    "concepts": [
      "permission",
      "connection",
      "retry",
      "state"
    ],
    "reference": "Model connection states explicitly, respect permissions, handle disconnects and timeouts, and use bounded reconnect logic. Validate messages and avoid assuming continuous availability.",
    "followup": "How would the UI distinguish pairing from a working data connection?"
  },
  {
    "title": "How would you build a nearby-places feature while limiting location access?",
    "topic": "Location features",
    "concepts": [
      "precision",
      "permission",
      "foreground",
      "cache"
    ],
    "reference": "Request only necessary precision and scope, handle stale or denied location and avoid background tracking unless essential. Provide understandable states and cache appropriate results.",
    "followup": "When would approximate location be sufficient?"
  },
  {
    "title": "How would you verify a shared mobile feature behaves correctly on both platforms?",
    "topic": "Cross-platform testing",
    "concepts": [
      "platform",
      "navigation",
      "permission",
      "test"
    ],
    "reference": "Test core logic plus platform-specific navigation, permissions, lifecycle and layout. Use representative real devices and avoid assuming shared code removes platform differences.",
    "followup": "Which platform behaviors would you include in a release checklist?"
  }
]);
banks["Cybersecurity Analyst"].push(...[
  {
    "title": "How would you preserve digital evidence during an investigation?",
    "topic": "Evidence handling",
    "concepts": [
      "integrity",
      "hash",
      "custody",
      "documentation"
    ],
    "reference": "Use approved collection methods, document who handled evidence and when, verify integrity with hashes and preserve originals. Follow scope and retention requirements.",
    "followup": "Why is a screenshot alone often insufficient evidence?"
  },
  {
    "title": "What does a zero-trust approach change about access decisions?",
    "topic": "Zero trust",
    "concepts": [
      "identity",
      "device",
      "verification",
      "least privilege"
    ],
    "reference": "Evaluate identity, device and context rather than trusting network location alone. Enforce least privilege and revisit access as conditions change; it is an architectural approach, not one product.",
    "followup": "How would this affect access from an internal network?"
  },
  {
    "title": "What would you do if an API key was committed to a repository?",
    "topic": "Secrets exposure",
    "concepts": [
      "revoke",
      "rotate",
      "scope",
      "logs"
    ],
    "reference": "Revoke or rotate the exposed credential, assess access logs and impact, remove inappropriate exposure and prevent recurrence. Deleting the current file does not invalidate copies or history.",
    "followup": "Why is rewriting Git history not enough on its own?"
  },
  {
    "title": "How would you protect backups against ransomware?",
    "topic": "Backup security",
    "concepts": [
      "offline",
      "immutable",
      "access",
      "restore"
    ],
    "reference": "Use isolated or immutable copies, restricted credentials, monitored backup jobs and tested restoration. Consider retention and recovery objectives rather than equating successful backup with recovery readiness.",
    "followup": "How would you test recovery without disrupting production?"
  },
  {
    "title": "How would you reduce session hijacking risk in a web app?",
    "topic": "Session security",
    "concepts": [
      "cookie",
      "rotation",
      "expiry",
      "tls"
    ],
    "reference": "Use TLS and appropriate secure cookie attributes, rotate identifiers at privilege changes, expire sessions appropriately and invalidate them when required. Address XSS and CSRF as relevant.",
    "followup": "Why should a session identifier change after login?"
  },
  {
    "title": "How would you confirm that a vulnerability has actually been fixed?",
    "topic": "Security validation",
    "concepts": [
      "retest",
      "regression",
      "scope",
      "evidence"
    ],
    "reference": "Reproduce the original issue safely within authorization, verify the intended control, inspect adjacent cases and add suitable regression tests. Record evidence and remaining limitations.",
    "followup": "Why might blocking one example payload leave the underlying flaw?"
  },
  {
    "title": "How would you triage an endpoint alert without assuming it is malicious?",
    "topic": "Endpoint protection",
    "concepts": [
      "process",
      "parent",
      "baseline",
      "context"
    ],
    "reference": "Inspect process lineage, file reputation, network activity and user context against a baseline. Correlate independent signals and follow escalation procedures before disruptive action.",
    "followup": "How could an administrative tool look suspicious but be legitimate?"
  },
  {
    "title": "How would you manage encryption keys separately from encrypted data?",
    "topic": "Encryption keys",
    "concepts": [
      "key",
      "access",
      "rotation",
      "recovery"
    ],
    "reference": "Store keys under controlled management, separate access permissions, log use and plan rotation and recovery. Protect against losing keys as well as unauthorized disclosure.",
    "followup": "What should happen to old encrypted data during key rotation?"
  },
  {
    "title": "How would you assess a vendor that processes sensitive company data?",
    "topic": "Third-party risk",
    "concepts": [
      "data",
      "access",
      "control",
      "contract"
    ],
    "reference": "Map data flows and access, evaluate relevant security controls and incident handling, and define contractual responsibilities and exit plans. Tailor depth to business impact.",
    "followup": "What evidence would you request beyond a vendor's marketing claims?"
  },
  {
    "title": "How would you measure whether security training improves behavior?",
    "topic": "Security awareness",
    "concepts": [
      "behavior",
      "baseline",
      "metric",
      "reporting"
    ],
    "reference": "Define observable outcomes, compare baselines and trends, and consider reporting quality and response times. Avoid measuring only attendance or blaming individuals for systemic weaknesses.",
    "followup": "How could a falling phishing-report count be misinterpreted?"
  }
]);
banks["AI / ML Engineer"].push(...[
  {
    "title": "How would you make an ML experiment reproducible?",
    "topic": "Experimental reproducibility",
    "concepts": [
      "seed",
      "version",
      "data",
      "environment"
    ],
    "reference": "Track data and code versions, configuration, environment and randomness. Record metrics and artifacts, while acknowledging hardware or nondeterministic operations may still affect exact results.",
    "followup": "Why is setting a random seed not always enough?"
  },
  {
    "title": "When would you use class weights instead of resampling?",
    "topic": "Class weighting",
    "concepts": [
      "imbalance",
      "weight",
      "resampling",
      "validation"
    ],
    "reference": "Compare both on representative validation data; weights change loss contributions while resampling changes training exposure. Avoid resampling before splitting and assess calibration and operational costs.",
    "followup": "How could oversampling before a train-test split leak information?"
  },
  {
    "title": "How would you adapt a pretrained vision model to a small dataset?",
    "topic": "Transfer learning",
    "concepts": [
      "pretrained",
      "freeze",
      "fine-tune",
      "validation"
    ],
    "reference": "Start with a suitable pretrained model, train a new head and selectively fine-tune with careful learning rates. Match preprocessing and evaluate on held-out representative data.",
    "followup": "When might freezing all feature layers limit performance?"
  },
  {
    "title": "How would you distinguish data drift from concept drift?",
    "topic": "Data drift",
    "concepts": [
      "distribution",
      "relationship",
      "labels",
      "monitor"
    ],
    "reference": "Data drift changes input distributions; concept drift changes the relationship to outcomes. Monitor features and performance with labels when available and investigate causes before retraining.",
    "followup": "Can input drift occur without degrading model performance?"
  },
  {
    "title": "How would you explain feature importance without claiming causation?",
    "topic": "Feature importance",
    "concepts": [
      "importance",
      "correlation",
      "permutation",
      "causation"
    ],
    "reference": "Explain the method and its limits, assess correlated features and validation behavior, and distinguish predictive association from causal influence. Importance can vary across methods and samples.",
    "followup": "Why can correlated features distort permutation importance?"
  },
  {
    "title": "How would you establish a baseline for classifying support tickets?",
    "topic": "Text classification",
    "concepts": [
      "tf-idf",
      "linear",
      "split",
      "metric"
    ],
    "reference": "Create leakage-safe splits, try TF-IDF with a simple classifier, evaluate appropriate per-class metrics and inspect errors before adding complexity.",
    "followup": "How would duplicate tickets across splits affect evaluation?"
  },
  {
    "title": "How would you build lag and rolling features without using future data?",
    "topic": "Time-series features",
    "concepts": [
      "lag",
      "window",
      "shift",
      "leakage"
    ],
    "reference": "Compute each feature only from information available at prediction time, shift rolling windows appropriately and respect entity boundaries. Validate chronologically.",
    "followup": "How would delayed data availability change your feature pipeline?"
  },
  {
    "title": "How would you reduce model inference latency while preserving quality?",
    "topic": "Serving optimization",
    "concepts": [
      "batch",
      "quantization",
      "profile",
      "latency"
    ],
    "reference": "Profile preprocessing, model execution and I/O, then evaluate batching, smaller models or quantization against quality and tail latency. Measure under realistic load.",
    "followup": "Why might larger batches improve throughput but hurt response time?"
  },
  {
    "title": "When would active learning help reduce labeling cost?",
    "topic": "Active learning",
    "concepts": [
      "uncertainty",
      "diversity",
      "label",
      "bias"
    ],
    "reference": "Select informative and diverse unlabeled examples for review, update the model and evaluate on an unbiased holdout. Account for selection bias and annotation quality.",
    "followup": "Why might repeatedly choosing only uncertain examples be problematic?"
  },
  {
    "title": "How would you evaluate an LLM feature before releasing it?",
    "topic": "LLM evaluation",
    "concepts": [
      "dataset",
      "rubric",
      "faithfulness",
      "latency"
    ],
    "reference": "Build representative evaluation cases and explicit rubrics, assess correctness and failure modes, and combine automated checks with human review. Track cost and latency; do not rely solely on another model's score.",
    "followup": "How would you test robustness to misleading instructions inside retrieved documents?"
  }
]);
banks["Full-stack Developer"].push(...[
  {
    "title": "How would you isolate data between organizations in a SaaS app?",
    "topic": "Multi-tenancy",
    "concepts": [
      "tenant",
      "authorization",
      "query",
      "isolation"
    ],
    "reference": "Derive trusted tenant context from authenticated access, enforce isolation on all reads and writes and test cross-tenant boundaries. Include caches, files and background jobs.",
    "followup": "Why must a tenant ID supplied by the client be validated?"
  },
  {
    "title": "Design a notification feature with read and unread states.",
    "topic": "Notifications",
    "concepts": [
      "event",
      "persistence",
      "idempotent",
      "preference"
    ],
    "reference": "Persist notifications with ownership and state, deduplicate triggering events and respect preferences. Keep delivery mechanisms separate from the authoritative inbox.",
    "followup": "How would you prevent duplicate notifications after a retry?"
  },
  {
    "title": "How would you preserve a long form without losing recent edits?",
    "topic": "Form drafts",
    "concepts": [
      "draft",
      "debounce",
      "version",
      "recovery"
    ],
    "reference": "Save drafts at appropriate intervals, show status, protect ownership and handle conflicts. Distinguish drafts from submitted records and recover gracefully after failure.",
    "followup": "How would two tabs editing the same draft interact?"
  },
  {
    "title": "How would you display scheduled events across time zones?",
    "topic": "Time handling",
    "concepts": [
      "utc",
      "timezone",
      "daylight",
      "format"
    ],
    "reference": "Store instants consistently and retain named time zones for recurring local schedules. Use timezone-aware conversion and handle daylight-saving ambiguity explicitly.",
    "followup": "Why is a fixed UTC offset insufficient for some recurring events?"
  },
  {
    "title": "How would you generate a large CSV report without timing out?",
    "topic": "File exports",
    "concepts": [
      "stream",
      "queue",
      "pagination",
      "authorization"
    ],
    "reference": "Use streaming or background generation, bounded data reads and secure expiring download access. Track status and handle cancellation and failures.",
    "followup": "How would you prevent spreadsheet formula injection in exported user text?"
  },
  {
    "title": "How would you roll out a risky feature gradually?",
    "topic": "Feature flags",
    "concepts": [
      "flag",
      "cohort",
      "monitor",
      "rollback"
    ],
    "reference": "Gate coherent behavior with a controlled flag, select rollout cohorts and monitor agreed metrics. Plan rollback, compatible data changes and eventual flag removal.",
    "followup": "Why can disabling a flag fail to undo a destructive data change?"
  },
  {
    "title": "How would you handle inconsistent error formats from multiple services?",
    "topic": "API contracts",
    "concepts": [
      "adapter",
      "contract",
      "error",
      "mapping"
    ],
    "reference": "Normalize service errors at a clear boundary into a documented client contract while preserving internal diagnostics. Avoid exposing sensitive details or losing retry semantics.",
    "followup": "How would the client distinguish an expired session from insufficient permission?"
  },
  {
    "title": "Design a progress indicator for a long-running report job.",
    "topic": "Background jobs",
    "concepts": [
      "job",
      "status",
      "polling",
      "retry"
    ],
    "reference": "Persist job identity and state, expose authorized status reads and update the UI through polling or streaming. Model terminal failures and safe retry rather than inventing progress percentages.",
    "followup": "How would you reconnect to a job after a page refresh?"
  },
  {
    "title": "How would you trace a user-visible error from browser to database?",
    "topic": "Observability",
    "concepts": [
      "correlation",
      "trace",
      "log",
      "privacy"
    ],
    "reference": "Propagate request correlation across boundaries, connect frontend errors with server traces and database timing, and redact sensitive content. Use release and environment context.",
    "followup": "How would you diagnose an error reported without a reproducible example?"
  },
  {
    "title": "How would you test a web app before a traffic increase?",
    "topic": "Load testing",
    "concepts": [
      "workload",
      "latency",
      "throughput",
      "bottleneck"
    ],
    "reference": "Model realistic user flows and concurrency, measure latency distributions and errors, and find limiting resources. Use an authorized isolated environment and define success criteria.",
    "followup": "Why is requests per second alone an incomplete performance measure?"
  }
]);
banks["Data Analyst"].push(...[
  {
    "title": "How would you resolve two teams reporting different active-user counts?",
    "topic": "Metric definitions",
    "concepts": [
      "definition",
      "window",
      "source",
      "filter"
    ],
    "reference": "Compare event definitions, time windows, identity resolution, filters and source freshness. Reconcile with sample records and agree on a documented metric contract.",
    "followup": "How could timezone boundaries create different daily counts?"
  },
  {
    "title": "How would you check whether a survey sample represents its target population?",
    "topic": "Sampling",
    "concepts": [
      "sample",
      "bias",
      "response",
      "weight"
    ],
    "reference": "Compare coverage and key characteristics, examine nonresponse and selection mechanisms and consider justified weighting. Explain remaining uncertainty rather than assuming sample size eliminates bias.",
    "followup": "Why can a very large convenience sample still be misleading?"
  },
  {
    "title": "When are medians and percentiles more useful than averages?",
    "topic": "Percentiles",
    "concepts": [
      "median",
      "skew",
      "percentile",
      "distribution"
    ],
    "reference": "Use medians and tail percentiles to describe skewed distributions and extreme experiences. Show context and sample size; no single statistic captures the full distribution.",
    "followup": "Why might average response time hide a bad user experience?"
  },
  {
    "title": "How would you trace an incorrect dashboard value to its source?",
    "topic": "Data lineage",
    "concepts": [
      "lineage",
      "transformation",
      "source",
      "reconcile"
    ],
    "reference": "Follow transformations from the metric back through models and raw events, reconcile intermediate totals and identify the first divergence. Track changes and assumptions.",
    "followup": "How would you tell whether a bug is in collection or aggregation?"
  },
  {
    "title": "What checks would you run before trusting a new dataset?",
    "topic": "Data validation",
    "concepts": [
      "schema",
      "range",
      "uniqueness",
      "completeness"
    ],
    "reference": "Validate schema and types, required fields, key uniqueness, plausible ranges and cross-field consistency. Compare coverage and totals with known sources and investigate exceptions.",
    "followup": "How would you distinguish valid rare values from ingestion errors?"
  },
  {
    "title": "How would you segment customers to answer a business question?",
    "topic": "Segmentation",
    "concepts": [
      "objective",
      "feature",
      "interpretability",
      "validation"
    ],
    "reference": "Begin with the decision, choose relevant behavior and value features, and compare simple rule-based segments with clustering. Validate stability and actionability.",
    "followup": "Why might statistically distinct segments still be useless to the business?"
  },
  {
    "title": "How would you separate seasonal patterns from underlying growth?",
    "topic": "Seasonality",
    "concepts": [
      "seasonality",
      "trend",
      "comparison",
      "history"
    ],
    "reference": "Use sufficient history, compare like periods and consider decomposition or suitable models. Account for calendar effects and structural changes and communicate uncertainty.",
    "followup": "Why can month-over-month growth be misleading for a seasonal business?"
  },
  {
    "title": "How would you handle an experiment with multiple success metrics?",
    "topic": "Experiments",
    "concepts": [
      "primary",
      "multiple",
      "guardrail",
      "predefine"
    ],
    "reference": "Predefine the primary outcome and guardrails, account for multiple testing when making several claims and report effect sizes and uncertainty. Avoid choosing a favorable metric afterward.",
    "followup": "How can testing many metrics inflate false-positive findings?"
  },
  {
    "title": "How do NULL values affect comparisons and aggregates?",
    "topic": "SQL nulls",
    "concepts": [
      "null",
      "unknown",
      "count",
      "coalesce"
    ],
    "reference": "NULL represents missing or unknown data; comparisons generally produce unknown rather than true or false. COUNT(column) excludes NULL while COUNT(*) counts rows; use explicit NULL handling appropriate to the meaning.",
    "followup": "Why does comparing a column to NULL with an equals sign fail to find missing values?"
  },
  {
    "title": "How would you determine whether an analysis-driven change worked?",
    "topic": "Decision follow-through",
    "concepts": [
      "baseline",
      "outcome",
      "comparison",
      "monitor"
    ],
    "reference": "Define the intended outcome and measurement plan before action, choose a credible comparison and monitor changes with context. Distinguish implementation success from causal business impact.",
    "followup": "What would you do if the metric improved but a key guardrail worsened?"
  }
]);
