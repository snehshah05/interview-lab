import {z} from 'zod';
import {banks} from './questions';
import {chooseQuestions} from './question-selection';
import {conceptCheck} from './evaluate';
import {questionSchema,sessionSchema} from './validation';
const exposureSchema=z.object({role:z.string(),title:z.string(),asked:z.string()});
const storeSchema=z.object({sessions:z.array(sessionSchema),exposures:z.array(exposureSchema)});
const KEY='interview-lab:practice:v1';
function read(){const raw=localStorage.getItem(KEY);return raw?storeSchema.parse(JSON.parse(raw)):{sessions:[],exposures:[]};}
function save(data:z.infer<typeof storeSchema>){localStorage.setItem(KEY,JSON.stringify(data));}
const inputSchema=z.object({role:z.string().refine(r=>Object.hasOwn(banks,r)),count:z.number().refine(n=>[5,10,15,20,25].includes(n)),questions:questionSchema.array().max(25).optional()});
export async function localRequest(path:string,options:RequestInit={}):Promise<Response>{
 try{
  const url=new URL(path,'https://interview.invalid');const method=options.method??'GET';
  if(url.pathname==='/api/evaluate'&&method==='POST'){
   const body=z.object({question:questionSchema,answer:z.string().min(10).max(15000)}).parse(JSON.parse(String(options.body)));
   return Response.json(conceptCheck(body.question,body.answer));
  }
  const data=read();
  if(url.pathname==='/api/interviews'){
   if(method==='GET')return Response.json(data.sessions);
   const session=sessionSchema.parse(JSON.parse(String(options.body)));
   data.sessions=[session,...data.sessions.filter(s=>s.id!==session.id)].slice(0,100);save(data);
   return Response.json({ok:true});
  }
  if(url.pathname==='/api/questions'){
   const role=method==='GET'?url.searchParams.get('role'):undefined;
   if(method==='GET')return Response.json({previous:[...new Set(data.exposures.filter(q=>q.role===role).map(q=>q.title))].slice(-300)});
   const body=inputSchema.parse(JSON.parse(String(options.body)));
   const seen=new Map<string,string>();
   for(const q of data.exposures)if(q.role===body.role)seen.set(q.title,q.asked);
   for(const s of [...data.sessions].reverse())if(s.role===body.role)for(const a of s.answers)if(!seen.has(a.question.title))seen.set(a.question.title,s.created);
   const questions=body.questions??chooseQuestions(body.role,body.count,seen);
   if(questions.length!==body.count||new Set(questions.map(q=>q.title)).size!==body.count)return Response.json({error:'Expected unique questions for the session'},{status:400});
   if(body.questions&&questions.some(q=>seen.has(q.title)))return Response.json({error:'AI repeated a previous question. Try again.'},{status:409});
   const now=new Date().toISOString();
   const current=new Set(questions.map(q=>q.title));
   data.exposures=data.exposures.filter(q=>q.role!==body.role||!current.has(q.title));
   data.exposures.push(...questions.map(q=>({role:body.role,title:q.title,asked:now})));
   data.exposures=data.exposures.slice(-10000);save(data);
   return Response.json({questions,reused:questions.filter(q=>seen.has(q.title)).length,mode:body.questions?'AI-generated':'Randomized practice'});
  }
  return Response.json({error:'Unknown operation'},{status:404});
 }catch{return Response.json({error:'Could not read or save browser data. Check that browser storage is available.'},{status:503});}
}
