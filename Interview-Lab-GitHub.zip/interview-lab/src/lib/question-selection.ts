import {banks,type Question} from './questions';
export function questionPool(role:string):Question[]{return (banks[role]??[]).flatMap(q=>[q,{...q,title:`${q.title} Use a concrete project example and explain the trade-offs behind your approach.`,reference:q.reference+' Ground the explanation in a concrete project, explain alternatives and justify the trade-offs.'},{...q,title:`${q.title} Describe a likely mistake, how you would detect it, and how you would verify your fix.`,reference:q.reference+' Identify a plausible failure, the evidence needed to diagnose it and a meaningful verification step.'}]);}
export function chooseQuestions(role:string,count:number,seen:Map<string,string>,random=()=>crypto.getRandomValues(new Uint32Array(1))[0]/4294967296){
 const pool=questionPool(role).map((q,i)=>({q,base:Math.floor(i/3),seen:seen.get(q.title),random:random()}));
 pool.sort((a,b)=>a.seen&&b.seen?a.seen.localeCompare(b.seen)||a.random-b.random:a.seen?1:b.seen?-1:a.random-b.random);
 const selected:Question[]=[];const bases=new Set<number>();
 // One question per core topic in a session, unseen variants first.
 for(const item of pool){if(bases.has(item.base))continue;selected.push(item.q);bases.add(item.base);if(selected.length===count)break}
 return selected;
}
