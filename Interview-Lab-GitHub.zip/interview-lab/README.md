# Interview Lab

A voice-first technical interview practice app built with React, TypeScript and Vite. The frontend runs on GitHub Pages; an optional Python service enables LLM feedback and fresh questions.

## Features

- Seven domains: frontend, backend, full-stack, mobile development, cybersecurity, AI/ML and data analysis.
- Sessions of 5, 10, 15, 20 or 25 questions.
- 175 core questions and 350 scenario variations. Unseen prompts are prioritized before older prompts repeat; each session uses distinct core questions.
- Mandatory camera and microphone access. Answering pauses when either device disconnects.
- Spoken questions using browser speech synthesis, with a static fictional interviewer portrait.
- Voice-only answers. Stop & submit associates the final transcript with its exact question.
- Concept coverage and communication-structure feedback, reference answers and follow-ups.
- Browser-local history and downloadable JSON reports.

## What runs on GitHub Pages

The app uses localStorage for saved interviews and question exposure history. Each browser has separate data; clearing site storage removes it. The website is public, but answers are not committed to GitHub or stored in the repository. Export reports for backup. Previous history from a different hosted origin is not automatically migrated.

Camera video remains on the device. Browser speech recognition may send audio to the browser provider; this app does not save raw microphone recordings. Chrome or Edge with camera/microphone permission is recommended. Browser support and speech services vary.

Default feedback is transparent concept matching, not LLM assessment. Technical correctness and confidence remain unscored. No emotion, eye-contact or confidence inference is active.

## Run locally

Use Node.js 24 and the pinned pnpm version:

```sh
corepack enable
pnpm install --frozen-lockfile
pnpm dev
```

Open the local URL printed by Vite, then allow camera and microphone access.

```sh
pnpm test
pnpm build
pnpm preview
```

The build is static and uses relative asset URLs, so it can run at a GitHub Pages project path.

## GitHub Pages deployment

Create the repository `snehshah05/interview-lab`, upload this source to `main`, and select **Settings → Pages → Source → GitHub Actions**. The included workflow tests, builds and publishes the `dist` directory on every push to `main`.

Expected URL after a successful deployment: `https://snehshah05.github.io/interview-lab/`.

## Optional Python / LLM service

GitHub Pages cannot run Python, Whisper, PostgreSQL or an LLM. These run separately. The Pages app works without the service; connect one through **Connections** to enable LLM evaluation and new questions.

With Python 3.11+ from the repository root:

```sh
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
python -m pip install -r backend/requirements.txt
```

Activate the virtual environment before installing dependencies. Copy `backend/.env.example` to `backend/.env`, set the LLM model and URL, then run:

```sh
python -m uvicorn backend.main:app --env-file backend/.env --host 127.0.0.1 --port 8000
```

Keep LLM credentials on the server, never in frontend code. Configure `ALLOWED_ORIGINS` for your frontend origin. A publicly hosted API needs authentication and rate limiting before exposing paid or private resources. Use HTTPS for a remote service. Accessing a local API from a hosted page depends on browser security restrictions; local frontend plus local API is the simplest local setup.

The optional `/transcribe` endpoint supports Whisper and `/archive` supports PostgreSQL. These are backend utilities; the Pages interface uses browser speech recognition and browser-local history. The camera observation utility is not active in the UI.

## Layout

- `src/App.tsx`: interview, device, transcript, history and report flows.
- `src/lib/questions.ts`: domain question banks.
- `src/lib/question-selection.ts`: randomized selection and repeat handling.
- `src/lib/local-api.ts`: validated browser storage and practice feedback.
- `backend/`: optional FastAPI service.
- `.github/workflows/pages.yml`: test, build and deployment workflow.

## Verification

TypeScript checking, the static production build, Python syntax and focused tests for question novelty, repeat handling, duplicate rejection, feedback and saved history pass. Physical webcam/microphone behavior depends on the browser and device and must be checked there.
